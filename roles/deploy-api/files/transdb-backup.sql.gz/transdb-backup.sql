--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.type_disclosure_responses DROP CONSTRAINT type_disclosure_responses_response_id_fkey;
ALTER TABLE ONLY public.type_disclosure_responses DROP CONSTRAINT type_disclosure_responses_disclosure_id_fkey;
ALTER TABLE ONLY public.law_enforcement_handbooks DROP CONSTRAINT law_enforcement_handbooks_transparency_report_id_fkey;
ALTER TABLE ONLY public.law_enforcement_actions DROP CONSTRAINT law_enforcement_actions_category_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_handbook_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_handbook_category_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_action_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_action_categories DROP CONSTRAINT law_enfocement_handbook_action_categories_handbook_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_action_categories DROP CONSTRAINT law_enfocement_handbook_action_categori_action_category_id_fkey;
ALTER TABLE ONLY public.government_requests_reports DROP CONSTRAINT government_requests_reports_transparency_report_id_fkey;
ALTER TABLE ONLY public.government_request_types DROP CONSTRAINT government_request_types_category_id_fkey;
ALTER TABLE ONLY public.government_request_report_type_disclosures DROP CONSTRAINT government_request_report_type_disclosures_request_type_id_fkey;
ALTER TABLE ONLY public.government_request_report_type_disclosures DROP CONSTRAINT government_request_report_type_disclosur_request_report_id_fkey;
ALTER TABLE ONLY public.data_retention_guides DROP CONSTRAINT data_retention_guides_transparency_report_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_guide_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_guide_data_item_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_guide_category_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_categories DROP CONSTRAINT data_retention_guide_categories_guide_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_categories DROP CONSTRAINT data_retention_guide_categories_guide_data_category_id_fkey;
ALTER TABLE ONLY public.data_items DROP CONSTRAINT data_items_category_id_fkey;
ALTER TABLE ONLY public.type_disclosure_responses DROP CONSTRAINT type_disclosure_responses_pkey;
ALTER TABLE ONLY public.transparency_reports DROP CONSTRAINT transparency_reports_pkey;
ALTER TABLE ONLY public.law_enforcement_handbooks DROP CONSTRAINT law_enforcement_handbooks_pkey;
ALTER TABLE ONLY public.law_enforcement_actions DROP CONSTRAINT law_enforcement_actions_pkey;
ALTER TABLE ONLY public.law_enforcement_action_categories DROP CONSTRAINT law_enforcement_action_categories_pkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_pkey;
ALTER TABLE ONLY public.law_enfocement_handbook_action_categories DROP CONSTRAINT law_enfocement_handbook_action_categories_pkey;
ALTER TABLE ONLY public.government_requests_reports DROP CONSTRAINT government_requests_reports_pkey;
ALTER TABLE ONLY public.government_request_types DROP CONSTRAINT government_request_types_pkey;
ALTER TABLE ONLY public.government_request_responses DROP CONSTRAINT government_request_responses_pkey;
ALTER TABLE ONLY public.government_request_report_type_disclosures DROP CONSTRAINT government_request_report_type_disclosures_pkey;
ALTER TABLE ONLY public.government_request_categories DROP CONSTRAINT government_request_categories_pkey;
ALTER TABLE ONLY public.data_retention_guides DROP CONSTRAINT data_retention_guides_pkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_pkey;
ALTER TABLE ONLY public.data_retention_guide_categories DROP CONSTRAINT data_retention_guide_categories_pkey;
ALTER TABLE ONLY public.data_items DROP CONSTRAINT data_items_pkey;
ALTER TABLE ONLY public.data_categories DROP CONSTRAINT data_categories_pkey;
ALTER TABLE public.type_disclosure_responses ALTER COLUMN type_disclosure_id DROP DEFAULT;
ALTER TABLE public.transparency_reports ALTER COLUMN report_id DROP DEFAULT;
ALTER TABLE public.law_enforcement_handbooks ALTER COLUMN handbook_id DROP DEFAULT;
ALTER TABLE public.law_enforcement_actions ALTER COLUMN action_id DROP DEFAULT;
ALTER TABLE public.law_enforcement_action_categories ALTER COLUMN category_id DROP DEFAULT;
ALTER TABLE public.law_enfocement_handbook_actions ALTER COLUMN handbook_action_id DROP DEFAULT;
ALTER TABLE public.law_enfocement_handbook_action_categories ALTER COLUMN handbook_category_id DROP DEFAULT;
ALTER TABLE public.government_requests_reports ALTER COLUMN report_id DROP DEFAULT;
ALTER TABLE public.government_request_types ALTER COLUMN type_id DROP DEFAULT;
ALTER TABLE public.government_request_responses ALTER COLUMN response_id DROP DEFAULT;
ALTER TABLE public.government_request_report_type_disclosures ALTER COLUMN disclosure_id DROP DEFAULT;
ALTER TABLE public.government_request_categories ALTER COLUMN category_id DROP DEFAULT;
ALTER TABLE public.data_retention_guides ALTER COLUMN guide_id DROP DEFAULT;
ALTER TABLE public.data_retention_guide_items ALTER COLUMN guide_item_id DROP DEFAULT;
ALTER TABLE public.data_retention_guide_categories ALTER COLUMN guide_category_id DROP DEFAULT;
ALTER TABLE public.data_items ALTER COLUMN item_id DROP DEFAULT;
ALTER TABLE public.data_categories ALTER COLUMN category_id DROP DEFAULT;
DROP SEQUENCE public.type_disclosure_responses_type_disclosure_id_seq;
DROP TABLE public.type_disclosure_responses;
DROP SEQUENCE public.transparency_reports_report_id_seq;
DROP TABLE public.transparency_reports;
DROP SEQUENCE public.law_enforcement_handbooks_handbook_id_seq;
DROP TABLE public.law_enforcement_handbooks;
DROP SEQUENCE public.law_enforcement_actions_action_id_seq;
DROP TABLE public.law_enforcement_actions;
DROP SEQUENCE public.law_enforcement_action_categories_category_id_seq;
DROP TABLE public.law_enforcement_action_categories;
DROP SEQUENCE public.law_enfocement_handbook_actions_handbook_action_id_seq;
DROP TABLE public.law_enfocement_handbook_actions;
DROP SEQUENCE public.law_enfocement_handbook_action_categor_handbook_category_id_seq;
DROP TABLE public.law_enfocement_handbook_action_categories;
DROP SEQUENCE public.government_requests_reports_report_id_seq;
DROP TABLE public.government_requests_reports;
DROP SEQUENCE public.government_request_types_type_id_seq;
DROP TABLE public.government_request_types;
DROP SEQUENCE public.government_request_responses_response_id_seq;
DROP TABLE public.government_request_responses;
DROP SEQUENCE public.government_request_report_type_disclosures_disclosure_id_seq;
DROP TABLE public.government_request_report_type_disclosures;
DROP SEQUENCE public.government_request_categories_category_id_seq;
DROP TABLE public.government_request_categories;
DROP SEQUENCE public.data_retention_guides_guide_id_seq;
DROP TABLE public.data_retention_guides;
DROP SEQUENCE public.data_retention_guide_items_guide_item_id_seq;
DROP TABLE public.data_retention_guide_items;
DROP SEQUENCE public.data_retention_guide_categories_guide_category_id_seq;
DROP TABLE public.data_retention_guide_categories;
DROP SEQUENCE public.data_items_item_id_seq;
DROP TABLE public.data_items;
DROP SEQUENCE public.data_categories_category_id_seq;
DROP TABLE public.data_categories;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: data_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_categories (
    category_id integer NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.data_categories OWNER TO transdb;

--
-- Name: data_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_categories_category_id_seq OWNER TO transdb;

--
-- Name: data_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_categories_category_id_seq OWNED BY data_categories.category_id;


--
-- Name: data_items; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_items (
    item_id integer NOT NULL,
    name character varying(255),
    description text,
    category_id integer
);


ALTER TABLE public.data_items OWNER TO transdb;

--
-- Name: data_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_items_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_items_item_id_seq OWNER TO transdb;

--
-- Name: data_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_items_item_id_seq OWNED BY data_items.item_id;


--
-- Name: data_retention_guide_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_retention_guide_categories (
    guide_id integer NOT NULL,
    guide_data_category_id integer NOT NULL,
    inclusion_status boolean,
    retention_status boolean,
    guide_category_id integer NOT NULL
);


ALTER TABLE public.data_retention_guide_categories OWNER TO transdb;

--
-- Name: data_retention_guide_categories_guide_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_retention_guide_categories_guide_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_retention_guide_categories_guide_category_id_seq OWNER TO transdb;

--
-- Name: data_retention_guide_categories_guide_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_retention_guide_categories_guide_category_id_seq OWNED BY data_retention_guide_categories.guide_category_id;


--
-- Name: data_retention_guide_items; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_retention_guide_items (
    guide_id integer NOT NULL,
    guide_data_item_id integer NOT NULL,
    narrative text,
    inclusion_status boolean,
    retention_status boolean,
    guide_item_id integer NOT NULL,
    guide_category_id integer,
    retention_period integer,
    retention_period_unit integer
);


ALTER TABLE public.data_retention_guide_items OWNER TO transdb;

--
-- Name: data_retention_guide_items_guide_item_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_retention_guide_items_guide_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_retention_guide_items_guide_item_id_seq OWNER TO transdb;

--
-- Name: data_retention_guide_items_guide_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_retention_guide_items_guide_item_id_seq OWNED BY data_retention_guide_items.guide_item_id;


--
-- Name: data_retention_guides; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_retention_guides (
    guide_id integer NOT NULL,
    inclusion_status boolean,
    complete_status boolean,
    narrative text,
    transparency_report_id integer,
    date_updated date
);


ALTER TABLE public.data_retention_guides OWNER TO transdb;

--
-- Name: data_retention_guides_guide_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_retention_guides_guide_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_retention_guides_guide_id_seq OWNER TO transdb;

--
-- Name: data_retention_guides_guide_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_retention_guides_guide_id_seq OWNED BY data_retention_guides.guide_id;


--
-- Name: government_request_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_categories (
    category_id integer NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.government_request_categories OWNER TO transdb;

--
-- Name: government_request_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_categories_category_id_seq OWNER TO transdb;

--
-- Name: government_request_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_categories_category_id_seq OWNED BY government_request_categories.category_id;


--
-- Name: government_request_report_type_disclosures; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_report_type_disclosures (
    disclosure_id integer NOT NULL,
    request_report_id integer,
    request_type_id integer
);


ALTER TABLE public.government_request_report_type_disclosures OWNER TO transdb;

--
-- Name: government_request_report_type_disclosures_disclosure_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_report_type_disclosures_disclosure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_report_type_disclosures_disclosure_id_seq OWNER TO transdb;

--
-- Name: government_request_report_type_disclosures_disclosure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_report_type_disclosures_disclosure_id_seq OWNED BY government_request_report_type_disclosures.disclosure_id;


--
-- Name: government_request_responses; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_responses (
    response_id integer NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.government_request_responses OWNER TO transdb;

--
-- Name: government_request_responses_response_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_responses_response_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_responses_response_id_seq OWNER TO transdb;

--
-- Name: government_request_responses_response_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_responses_response_id_seq OWNED BY government_request_responses.response_id;


--
-- Name: government_request_types; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_types (
    type_id integer NOT NULL,
    category_id integer,
    name character varying(255),
    description text
);


ALTER TABLE public.government_request_types OWNER TO transdb;

--
-- Name: government_request_types_type_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_types_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_types_type_id_seq OWNER TO transdb;

--
-- Name: government_request_types_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_types_type_id_seq OWNED BY government_request_types.type_id;


--
-- Name: government_requests_reports; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_requests_reports (
    report_id integer NOT NULL,
    transparency_report_id integer,
    inclusion_status boolean,
    complete_status boolean,
    narrative text,
    date_updated date
);


ALTER TABLE public.government_requests_reports OWNER TO transdb;

--
-- Name: government_requests_reports_report_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_requests_reports_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_requests_reports_report_id_seq OWNER TO transdb;

--
-- Name: government_requests_reports_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_requests_reports_report_id_seq OWNED BY government_requests_reports.report_id;


--
-- Name: law_enfocement_handbook_action_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enfocement_handbook_action_categories (
    handbook_id integer NOT NULL,
    action_category_id integer NOT NULL,
    inclusion_status boolean,
    handbook_category_id integer NOT NULL
);


ALTER TABLE public.law_enfocement_handbook_action_categories OWNER TO transdb;

--
-- Name: law_enfocement_handbook_action_categor_handbook_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enfocement_handbook_action_categor_handbook_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enfocement_handbook_action_categor_handbook_category_id_seq OWNER TO transdb;

--
-- Name: law_enfocement_handbook_action_categor_handbook_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enfocement_handbook_action_categor_handbook_category_id_seq OWNED BY law_enfocement_handbook_action_categories.handbook_category_id;


--
-- Name: law_enfocement_handbook_actions; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enfocement_handbook_actions (
    handbook_id integer NOT NULL,
    action_id integer NOT NULL,
    narrative text,
    inclusion_status boolean,
    handbook_category_id integer,
    handbook_action_id integer NOT NULL
);


ALTER TABLE public.law_enfocement_handbook_actions OWNER TO transdb;

--
-- Name: law_enfocement_handbook_actions_handbook_action_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enfocement_handbook_actions_handbook_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enfocement_handbook_actions_handbook_action_id_seq OWNER TO transdb;

--
-- Name: law_enfocement_handbook_actions_handbook_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enfocement_handbook_actions_handbook_action_id_seq OWNED BY law_enfocement_handbook_actions.handbook_action_id;


--
-- Name: law_enforcement_action_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enforcement_action_categories (
    category_id integer NOT NULL,
    name character varying(255),
    action_selection_type integer,
    description text
);


ALTER TABLE public.law_enforcement_action_categories OWNER TO transdb;

--
-- Name: law_enforcement_action_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enforcement_action_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enforcement_action_categories_category_id_seq OWNER TO transdb;

--
-- Name: law_enforcement_action_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enforcement_action_categories_category_id_seq OWNED BY law_enforcement_action_categories.category_id;


--
-- Name: law_enforcement_actions; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enforcement_actions (
    action_id integer NOT NULL,
    category_id integer,
    name character varying(255),
    narrative text,
    narrative_label character varying(255),
    inclusion_status_default boolean
);


ALTER TABLE public.law_enforcement_actions OWNER TO transdb;

--
-- Name: law_enforcement_actions_action_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enforcement_actions_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enforcement_actions_action_id_seq OWNER TO transdb;

--
-- Name: law_enforcement_actions_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enforcement_actions_action_id_seq OWNED BY law_enforcement_actions.action_id;


--
-- Name: law_enforcement_handbooks; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enforcement_handbooks (
    handbook_id integer NOT NULL,
    inclusion_status boolean,
    complete_status boolean,
    narrative text,
    date_updated date,
    date_updated_inclusion_status boolean,
    transparency_report_id integer
);


ALTER TABLE public.law_enforcement_handbooks OWNER TO transdb;

--
-- Name: law_enforcement_handbooks_handbook_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enforcement_handbooks_handbook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enforcement_handbooks_handbook_id_seq OWNER TO transdb;

--
-- Name: law_enforcement_handbooks_handbook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enforcement_handbooks_handbook_id_seq OWNED BY law_enforcement_handbooks.handbook_id;


--
-- Name: transparency_reports; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE transparency_reports (
    report_id integer NOT NULL,
    publication_status boolean,
    complete_status boolean,
    publication_date date,
    report_period_start date,
    report_period_end date,
    author_name character varying(255),
    date_updated date
);


ALTER TABLE public.transparency_reports OWNER TO transdb;

--
-- Name: transparency_reports_report_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE transparency_reports_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transparency_reports_report_id_seq OWNER TO transdb;

--
-- Name: transparency_reports_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE transparency_reports_report_id_seq OWNED BY transparency_reports.report_id;


--
-- Name: type_disclosure_responses; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE type_disclosure_responses (
    response_id integer NOT NULL,
    disclosure_id integer NOT NULL,
    count integer,
    type_disclosure_id integer NOT NULL
);


ALTER TABLE public.type_disclosure_responses OWNER TO transdb;

--
-- Name: type_disclosure_responses_type_disclosure_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE type_disclosure_responses_type_disclosure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_disclosure_responses_type_disclosure_id_seq OWNER TO transdb;

--
-- Name: type_disclosure_responses_type_disclosure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE type_disclosure_responses_type_disclosure_id_seq OWNED BY type_disclosure_responses.type_disclosure_id;


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_categories ALTER COLUMN category_id SET DEFAULT nextval('data_categories_category_id_seq'::regclass);


--
-- Name: item_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_items ALTER COLUMN item_id SET DEFAULT nextval('data_items_item_id_seq'::regclass);


--
-- Name: guide_category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_categories ALTER COLUMN guide_category_id SET DEFAULT nextval('data_retention_guide_categories_guide_category_id_seq'::regclass);


--
-- Name: guide_item_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items ALTER COLUMN guide_item_id SET DEFAULT nextval('data_retention_guide_items_guide_item_id_seq'::regclass);


--
-- Name: guide_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guides ALTER COLUMN guide_id SET DEFAULT nextval('data_retention_guides_guide_id_seq'::regclass);


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_categories ALTER COLUMN category_id SET DEFAULT nextval('government_request_categories_category_id_seq'::regclass);


--
-- Name: disclosure_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_report_type_disclosures ALTER COLUMN disclosure_id SET DEFAULT nextval('government_request_report_type_disclosures_disclosure_id_seq'::regclass);


--
-- Name: response_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_responses ALTER COLUMN response_id SET DEFAULT nextval('government_request_responses_response_id_seq'::regclass);


--
-- Name: type_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_types ALTER COLUMN type_id SET DEFAULT nextval('government_request_types_type_id_seq'::regclass);


--
-- Name: report_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_requests_reports ALTER COLUMN report_id SET DEFAULT nextval('government_requests_reports_report_id_seq'::regclass);


--
-- Name: handbook_category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories ALTER COLUMN handbook_category_id SET DEFAULT nextval('law_enfocement_handbook_action_categor_handbook_category_id_seq'::regclass);


--
-- Name: handbook_action_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions ALTER COLUMN handbook_action_id SET DEFAULT nextval('law_enfocement_handbook_actions_handbook_action_id_seq'::regclass);


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_action_categories ALTER COLUMN category_id SET DEFAULT nextval('law_enforcement_action_categories_category_id_seq'::regclass);


--
-- Name: action_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_actions ALTER COLUMN action_id SET DEFAULT nextval('law_enforcement_actions_action_id_seq'::regclass);


--
-- Name: handbook_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_handbooks ALTER COLUMN handbook_id SET DEFAULT nextval('law_enforcement_handbooks_handbook_id_seq'::regclass);


--
-- Name: report_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY transparency_reports ALTER COLUMN report_id SET DEFAULT nextval('transparency_reports_report_id_seq'::regclass);


--
-- Name: type_disclosure_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY type_disclosure_responses ALTER COLUMN type_disclosure_id SET DEFAULT nextval('type_disclosure_responses_type_disclosure_id_seq'::regclass);


--
-- Data for Name: data_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_categories (category_id, name, description) FROM stdin;
5	Personally Identifiable Information	Personal information means information about an identifiable individual. Canadian court decisions mean that this definition should be given a broad an expansive interpretation. In part, this means that information about an individual can merely relate to an individual, that information can be personal while simultaneously pertaining to more than just one person, that even public information can be personal, and that what is often core to the definition is that an individual is identifiable by way of the information, even if they are not identified using it.
6	Content	Content information refers to data which discloses the explicit meaning of a conversation, such as contents of files or communications.
4	Subscriber Data	Subscriber data refers to that collected by organizations, or provided by individuals voluntarily, in the course of signing up for accounts or fulfilling services or product orders.
19	Transmission Data	Transmission data orders are obtained using a transmission data recorder order, as denoted under s.492.2 of the Criminal Code. These orders are used to obtain data that is obtained by dialling, addressing, routing, or signalling, such as incoming and outgoing times of calls, non-content information associated with text messages or chat-based communications, or other data that does not reveal the content of the communication or message. Transmission data is more commonly known as 'metadata'.
\.


--
-- Name: data_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_categories_category_id_seq', 20, true);


--
-- Data for Name: data_items; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_items (item_id, name, description, category_id) FROM stdin;
51	dfgdfg	dfgdfgs sdfgsdfg	\N
48	asdf asdf asdf	a sdf asd fasdf	\N
49	xfbxcvbxcv dsfg sdfg	sd gsdf gsdfg	\N
50	asdfasdf	asdfasdf	\N
20	Web traffic logs	test	\N
21	Call logs	test	\N
22	Time and date of communications	test	\N
23	Other	test	\N
32	cell tower information	dump that	\N
33	cell tower information!	dump that	\N
34	That cell tower info, though	dump that	\N
35	That cell tower info, though	dump that	\N
36	That cell tower info, though	dump that	\N
37	That cell tower info, though	dump that	\N
38	That cell tower info, though	dump that	\N
39	That cell tower info, though	dump that	\N
40	test	test test	\N
41	test	test test	\N
42	asdfasdf	adfgsdfg sfdsfgd	\N
43	test test	test	\N
44	asdfasdf	asdfasdfasd	\N
45	Cell tower info	test	\N
47	dfhgdf	dfgdfg	\N
62	Other	test	19
59	Web traffic logs		19
60	Call logs		19
61	Time and date of communications		19
69	Messages between individual and organization		6
70	Messages between users		6
71	Content posted to service		6
72	Other		6
63	Geolocation		5
64	IP Address		5
65	Websites visited		5
66	Websites visited (external)		5
67	Search history		5
68	Call logs		5
74	Billing Info		4
75	Email Address		4
76	Phone Number		4
77	Username		4
78	Other		4
73	Address		4
\.


--
-- Name: data_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_items_item_id_seq', 82, true);


--
-- Data for Name: data_retention_guide_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_retention_guide_categories (guide_id, guide_data_category_id, inclusion_status, retention_status, guide_category_id) FROM stdin;
32	6	f	\N	116
32	5	f	\N	117
32	4	f	\N	118
33	6	f	\N	122
33	4	f	\N	124
33	5	t	\N	123
34	6	f	\N	127
34	5	f	\N	128
34	4	f	\N	129
35	6	f	\N	132
35	5	f	\N	133
35	4	f	\N	134
36	6	f	\N	136
36	5	f	\N	137
36	4	f	\N	138
36	19	t	\N	135
\.


--
-- Name: data_retention_guide_categories_guide_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_retention_guide_categories_guide_category_id_seq', 138, true);


--
-- Data for Name: data_retention_guide_items; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_retention_guide_items (guide_id, guide_data_item_id, narrative, inclusion_status, retention_status, guide_item_id, guide_category_id, retention_period, retention_period_unit) FROM stdin;
36	61	\N	f	\N	652	135	\N	\N
36	62	\N	f	\N	653	135	\N	\N
36	69	\N	f	\N	654	136	\N	\N
36	70	\N	f	\N	655	136	\N	\N
36	71	\N	f	\N	656	136	\N	\N
36	72	\N	f	\N	657	136	\N	\N
36	63	\N	f	\N	658	137	\N	\N
36	64	\N	f	\N	659	137	\N	\N
36	65	\N	f	\N	660	137	\N	\N
36	66	\N	f	\N	661	137	\N	\N
36	67	\N	f	\N	662	137	\N	\N
36	68	\N	f	\N	663	137	\N	\N
36	73	\N	f	\N	664	138	\N	\N
36	74	\N	f	\N	665	138	\N	\N
36	75	\N	f	\N	666	138	\N	\N
36	76	\N	f	\N	667	138	\N	\N
36	77	\N	f	\N	668	138	\N	\N
36	78	\N	f	\N	669	138	\N	\N
36	59	\N	t	\N	650	135	123	2
36	60	\N	t	\N	651	135	\N	\N
32	69	\N	f	\N	560	116	\N	\N
32	70	\N	f	\N	561	116	\N	\N
32	71	\N	f	\N	562	116	\N	\N
32	72	\N	f	\N	563	116	\N	\N
32	63	\N	f	\N	564	117	\N	\N
32	64	\N	f	\N	565	117	\N	\N
32	65	\N	f	\N	566	117	\N	\N
32	66	\N	f	\N	567	117	\N	\N
32	67	\N	f	\N	568	117	\N	\N
32	68	\N	f	\N	569	117	\N	\N
32	73	\N	f	\N	570	118	\N	\N
32	74	\N	f	\N	571	118	\N	\N
32	75	\N	f	\N	572	118	\N	\N
32	76	\N	f	\N	573	118	\N	\N
32	77	\N	f	\N	574	118	\N	\N
32	78	\N	f	\N	575	118	\N	\N
33	69	\N	f	\N	585	122	\N	\N
33	70	\N	f	\N	586	122	\N	\N
33	71	\N	f	\N	587	122	\N	\N
33	72	\N	f	\N	588	122	\N	\N
33	63	\N	f	\N	589	123	\N	\N
33	65	\N	f	\N	591	123	\N	\N
33	67	\N	f	\N	593	123	\N	\N
33	73	\N	f	\N	595	124	\N	\N
33	74	\N	f	\N	596	124	\N	\N
33	75	\N	f	\N	597	124	\N	\N
33	76	\N	f	\N	598	124	\N	\N
33	77	\N	f	\N	599	124	\N	\N
33	78	\N	f	\N	600	124	\N	\N
33	64	\N	t	\N	590	123	\N	\N
33	66	\N	t	\N	592	123	\N	\N
33	68	\N	t	\N	594	123	\N	\N
34	69	\N	f	\N	610	127	\N	\N
34	70	\N	f	\N	611	127	\N	\N
34	71	\N	f	\N	612	127	\N	\N
34	72	\N	f	\N	613	127	\N	\N
34	63	\N	f	\N	614	128	\N	\N
34	64	\N	f	\N	615	128	\N	\N
34	65	\N	f	\N	616	128	\N	\N
34	66	\N	f	\N	617	128	\N	\N
34	67	\N	f	\N	618	128	\N	\N
34	68	\N	f	\N	619	128	\N	\N
34	73	\N	f	\N	620	129	\N	\N
34	74	\N	f	\N	621	129	\N	\N
34	75	\N	f	\N	622	129	\N	\N
34	76	\N	f	\N	623	129	\N	\N
34	77	\N	f	\N	624	129	\N	\N
34	78	\N	f	\N	625	129	\N	\N
35	69	\N	f	\N	634	132	\N	\N
35	70	\N	f	\N	635	132	\N	\N
35	71	\N	f	\N	636	132	\N	\N
35	72	\N	f	\N	637	132	\N	\N
35	63	\N	f	\N	638	133	\N	\N
35	64	\N	f	\N	639	133	\N	\N
35	65	\N	f	\N	640	133	\N	\N
35	66	\N	f	\N	641	133	\N	\N
35	67	\N	f	\N	642	133	\N	\N
35	68	\N	f	\N	643	133	\N	\N
35	73	\N	f	\N	644	134	\N	\N
35	74	\N	f	\N	645	134	\N	\N
35	75	\N	f	\N	646	134	\N	\N
35	76	\N	f	\N	647	134	\N	\N
35	77	\N	f	\N	648	134	\N	\N
35	78	\N	f	\N	649	134	\N	\N
\.


--
-- Name: data_retention_guide_items_guide_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_retention_guide_items_guide_item_id_seq', 669, true);


--
-- Data for Name: data_retention_guides; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_retention_guides (guide_id, inclusion_status, complete_status, narrative, transparency_report_id, date_updated) FROM stdin;
1	t	f	test test test	\N	\N
2	t	f	This is a test. Yep.sd ""asda""	\N	\N
4	t	f	test	\N	\N
5	t	f	asfdasdf	\N	\N
8	t	f	test tes test	\N	\N
9	t	f	sadsd	\N	\N
7	t	f	asdfasdf sdafasdf	\N	\N
10	t	f	sdfgsdfgsdfg	\N	\N
11	t	f	fghdfghdfgh	\N	\N
12	\N	\N	fghfgh	\N	\N
22	\N	\N	\N	\N	\N
21	\N	\N	xfgfg sdf sdf gdsf gsdfg sdfg sdfg sdfg	\N	\N
20	\N	\N	\N	\N	\N
16	\N	\N	\N	\N	\N
19	\N	\N	asdf asdf asdf asdf	\N	\N
18	\N	\N	\N	\N	\N
17	\N	\N	\N	\N	\N
15	\N	\N	\N	\N	\N
14	\N	\N	\N	\N	\N
13	\N	\N	\N	\N	\N
23	\N	\N	\N	\N	\N
33	\N	\N	\N	70	2016-06-18
32	\N	\N	\N	69	2016-06-18
34	t	t	\N	72	2016-06-18
35	t	\N	\N	73	2016-06-19
36	\N	t	sadasd asdf	74	2016-06-19
\.


--
-- Name: data_retention_guides_guide_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_retention_guides_guide_id_seq', 36, true);


--
-- Data for Name: government_request_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_categories (category_id, name, description) FROM stdin;
1	General Disclosures	asdfasdf!!
2	Court Ordered (Warranted) Disclosures	Court ordered disclosures refer to production orders, summons, subpoenas, and search warrants that are issued by a judge or judicial officer. They compel a company to collect and disclose information under the organization's control. In some cases an organization may challenge the disclosure of the information prior to disclosing it to the requesting government agency. Organizations should consult with counsel to determine their legal options in responding to court ordered disclosures of information to government agencies.\n\nThere are many different types of court ordered (warranted) disclosures. Some of the most common types of disclosures are included here by default.
5	Other Disclosures	\N
\.


--
-- Name: government_request_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_categories_category_id_seq', 5, true);


--
-- Data for Name: government_request_report_type_disclosures; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_report_type_disclosures (disclosure_id, request_report_id, request_type_id) FROM stdin;
194	23	12
195	23	13
196	23	8
197	23	7
198	23	9
199	23	10
200	23	11
201	23	3
202	23	5
203	23	6
204	23	4
205	23	1
207	24	12
208	24	13
209	24	8
210	24	7
211	24	9
212	24	10
213	24	11
214	24	3
215	24	5
216	24	6
217	24	4
218	24	1
219	25	12
220	25	13
221	25	8
222	25	7
223	25	9
224	25	10
225	25	11
226	25	3
227	25	5
228	25	6
229	25	4
230	25	1
231	26	12
232	26	13
233	26	8
234	26	7
235	26	9
236	26	10
237	26	11
238	26	3
239	26	5
240	26	6
241	26	4
242	26	1
\.


--
-- Name: government_request_report_type_disclosures_disclosure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_report_type_disclosures_disclosure_id_seq', 242, true);


--
-- Data for Name: government_request_responses; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_responses (response_id, name, description) FROM stdin;
2	Number of requests	Counting the number of requests entails adding the voluntary or court-mandated requests or orders received by an organization, as appropriate for each of the types of reporting categories.
4	Number of requests rejected	Organizations may sometimes reject requests for information that are made by government agencies. Rejections might be on the basis of improper request formats, on the basis of refusing to provide information absent a court order, or on the basis of other process or legal grounds. When preparing their reports, organizations should tabulate all of the legal or voluntary requests that they refuse, instead of tabulating the number of subscribers who would otherwise be affected by the request.
5	Number of requests contested	Organizations may sometimes dispute the requests that they receive from government agencies as a result of improperly scoped legal requests, on the basis of erroneous legal authorities being used to compel data from an organization, or on the basis of doubts concerning the legality or constitutionality of the request. Organizations should count each request they oppose, as opposed to tabulating the number of subscribers/accounts/customers who are affected by the initial request and subsequent contestation.
6	Number of requests for which the organization has no data	Government agencies may sometimes make requests or demands for information where the organization does not possess any relevant information. Organizations should count each request for which they lack data, as opposed to tabulating the number of subscribers, or accounts, or customers who would be affected by the request but for whom the organization possesses no relevant data.
7	Number of requests for which partial information disclosed	Government agencies may sometimes make requests or demands for information where the organization possesses only some relevant information. Organizations should count each request for which they partially possess data, as opposed to tabulating the number of subscribers/accounts/customers who would be affected by the request but for whom the organization only partially possesses data.
8	Number of requests for which information is fully disclosed	Government agencies may sometimes make requests or demands for information where the organization fully discloses the requested or demanded information. Organizations should count each request for which they fully disclose data, as opposed to tabulating the number of subscribers/accounts/customers who are affected by the disclosure.
9	Number of users notified	Government agencies' requests will often affect a series of an organization's subscribers, customers, or users. Sometimes, though not always, organizations may notify those affected of the request. Organizations should count each affected person that they notify of the request; where they a barred from informing all those affected an organization might denote that with a footnote associated with the reported number.
3	Number of subscribers / accounts / customers affected	It is possible that a single request might affect multiple subscribers, or accounts, or customers. A single order might name or otherwise identify each of the subscribers, or accounts, or customers or include an 'identifier' -- a piece of data that is then used by the organization to subsequently identify the subscribers, or accounts, or customers associated with the request. When preparing their reports, organizations should tabulate all of the subscribers, or accounts, or customers affected by each of the types of reporting category requests.
\.


--
-- Name: government_request_responses_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_responses_response_id_seq', 9, true);


--
-- Data for Name: government_request_types; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_types (type_id, category_id, name, description) FROM stdin;
1	1	Voluntary Disclosure Following Government Request	Government agencies will sometimes ask organizations to voluntarily provide certain information to the requesting authority. In some cases these requests may be made where the agency does not believe a warrant or court order is required to obtain the information, such as when conducting criminal investigations, to location or notify next-of-kin, return property, or help search for missing persons. Organizations are permitted to ask the requesting agency to return with a court order or explain what statute requires the disclosure before volunteering the requested information.
3	1	Voluntary Disclosure at Organization's Initiative	Organizations may voluntarily share information with government agencies, though organizations may prefer to consult with counsel before doing so in order to ensure they are properly respecting any terms of service, contracts, or other guarantees made between the organization and its customers/subscribers/users, as well as acting in compliance with Canadian law. When voluntarily disclosing information the organization provides information without the receiving government agency in question first requesting the relevant information.
4	1	Disclosure in Emergency or Exigent Circumstances	Government agencies may sometimes request rapid or immediate access to information retained by organizations due to exigent circumstances, where the agencies would normally require a court order to access the information in question. Such requests may be for: identifying information (e.g. customer name, telephone number, mailing address, email address, or other information needed by the organization to identify its subscribers or customers) as well as communications content or transmission data.
5	1	Disclosures to Comply with Federal Law	Federal government agencies may sometimes compel organizations to disclose information by exercising statutory authorities; this means that the agencies do not require a court order to compel the information from an organization. Some organizations refer to these as 'government requirement letters'.
6	1	Disclosures to Comply with Provincial Law	Provincial government agencies may sometimes compel organizations to disclose information by exercising statutory authorities; this means that the agencies do not require a court order to compel the information from an organization. Some organizations refer to these as 'government requirement letters'.
7	2	Basic identifying information (court ordered)	Such orders compel an organization to collect and disclose personal identifiers associated with a subscribers/customer/user. Identifiers may include customer name, telephone number, mailing address, email address, or other identifiers needed to identify a person where those identifiers enjoy a reasonable expectation of privacy and can only be disclosed pursuant to a court order.
8	2	Tracking data	Tracking data orders are obtained using tracking warrants, as denoted under s.492.1 of the Criminal Code. These orders are used to obtain data that relates to the location of a transaction, individual, or thing.
9	2	Transmission data	Transmission data orders are obtained using a transmission data recorder order, as denoted under s.492.2 of the Criminal Code. These orders are used to obtain data that is obtained by dialling, addressing, routing, or signalling, such as incoming and outgoing times of calls, non-content information associated with text messages or chat-based communications, or other data that does not reveal the content of the communication or message. Transmission data is more commonly known as 'metadata'.
10	2	Stored communications and other stored data	Stored communications and other stored data is often obtained using a warrant and production orders, as denoted under s.487, 487.01, and 487.014-487.018 of the Criminal Code. These orders may refer to historical data that includes the content of stored communications including email, chat messages, photos, documents, or any other kinds of stored data.
11	2	Real time interceptions	Real time interceptions are often obtained using a wiretap warrant, as denoted under Part VI of the Criminal Code. These orders may refer to private communications which are intercepted by means of electro-magnetic, acoustic, mechanical, or other means and involve the live capture of communications that are intermediated or accessible by the organization.
12	5	Foreign Agency Requests (Court Ordered)	Canadian organizations may sometimes receive requests from non-Canadian agencies for access to information held by to Canadian organization. Such orders may be accompanied by a court order from the agency's jurisdiction. Alternately, the foreign order might be facilitated by Canadian agencies per the Mutual Legal Assistance in Criminal Matters Act.
13	5	Preservation Demands and Orders	Preservation demands and orders can be obtained under s.487.012 and 487.013 of the Criminal Code. Demands are made by peace or public officers whereas orders are made pursuant to judicial authority. These orders compel an organization to retain to identified information for 21 days (for domestic demands and orders) or 90 days (where the demand or order is made in order to assist an international investigation). Organizations are not required to disclose information prior to receiving a production order from the agency which served the demand or order. \nProduction orders are used to compel information from organizations, often after the organization has previously been compelled to preserve information after receiving a preservation demand or order. The preservation demands and orders category is used to identify the frequency at which preservation demands or orders are received, whereas the disclosure of actual data is reflected in one of the relevant court ordered disclosure category.
\.


--
-- Name: government_request_types_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_types_type_id_seq', 24, true);


--
-- Data for Name: government_requests_reports; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_requests_reports (report_id, transparency_report_id, inclusion_status, complete_status, narrative, date_updated) FROM stdin;
5	\N	\N	\N	\N	\N
13	\N	\N	\N	asdf asdf asdf asdf	\N
12	\N	\N	\N	\N	\N
10	\N	\N	\N	\N	\N
9	\N	\N	\N	\N	\N
11	\N	\N	\N	\N	\N
8	\N	\N	\N	\N	\N
7	\N	\N	\N	\N	\N
6	\N	\N	\N	\N	\N
23	69	\N	\N	\N	\N
24	70	\N	\N	\N	2016-06-18
25	72	f	t	\N	2016-06-18
26	74	\N	\N		2016-06-19
\.


--
-- Name: government_requests_reports_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_requests_reports_report_id_seq', 26, true);


--
-- Name: law_enfocement_handbook_action_categor_handbook_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enfocement_handbook_action_categor_handbook_category_id_seq', 394, true);


--
-- Data for Name: law_enfocement_handbook_action_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enfocement_handbook_action_categories (handbook_id, action_category_id, inclusion_status, handbook_category_id) FROM stdin;
45	11	f	339
45	10	f	340
45	8	f	342
45	7	f	343
45	6	f	344
45	5	f	345
45	4	f	346
45	3	f	347
45	2	f	348
46	11	f	351
46	10	f	352
46	8	f	354
46	7	f	355
46	6	f	356
46	4	f	358
46	3	f	359
46	2	f	360
46	5	t	357
47	11	f	364
47	10	f	365
47	8	f	366
47	7	f	367
47	6	f	368
47	5	f	369
47	4	f	370
47	3	f	371
47	2	f	372
48	11	f	375
48	10	f	376
48	8	f	377
48	7	f	378
48	6	f	379
48	5	f	380
48	4	f	381
48	3	f	382
48	2	f	383
49	11	f	386
49	10	f	387
49	8	f	388
49	7	f	389
49	6	f	390
49	5	f	391
49	4	f	392
49	3	f	393
49	2	t	394
\.


--
-- Data for Name: law_enfocement_handbook_actions; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enfocement_handbook_actions (handbook_id, action_id, narrative, inclusion_status, handbook_category_id, handbook_action_id) FROM stdin;
45	32	\N	f	339	880
45	33	\N	f	339	881
45	34	\N	f	339	882
45	35	\N	f	339	883
45	25	\N	f	340	884
45	26	\N	f	340	885
45	27	\N	f	340	886
45	23	\N	t	342	888
45	19	\N	f	343	889
45	20	\N	f	343	890
45	21	\N	f	343	891
45	22	\N	f	343	892
45	16	\N	f	344	893
45	17	\N	f	344	894
45	18	\N	f	344	895
45	28	\N	f	345	896
45	29	\N	f	345	897
45	31	\N	f	345	898
45	10	\N	f	346	899
45	11	\N	f	346	900
45	12	\N	f	346	901
45	13	\N	f	346	902
45	14	\N	f	346	903
45	15	\N	f	346	904
45	6	\N	f	347	905
45	7	\N	f	347	906
45	8	\N	f	347	907
45	9	\N	f	347	908
45	1	\N	f	348	909
45	2	\N	f	348	910
45	3	\N	f	348	911
45	4	\N	f	348	912
45	5	\N	f	348	913
45	45	??	t	340	914
46	32	\N	f	351	917
46	33	\N	f	351	918
46	34	\N	f	351	919
46	35	\N	f	351	920
46	25	\N	f	352	921
46	26	\N	f	352	922
46	27	\N	f	352	923
46	45	\N	f	352	924
46	23	\N	t	354	926
46	19	\N	f	355	927
46	20	\N	f	355	928
46	21	\N	f	355	929
46	22	\N	f	355	930
46	16	\N	f	356	931
46	17	\N	f	356	932
46	18	\N	f	356	933
46	28	\N	f	357	934
46	29	\N	f	357	935
46	31	\N	f	357	936
46	10	\N	f	358	937
46	11	\N	f	358	938
46	12	\N	f	358	939
46	13	\N	f	358	940
46	14	\N	f	358	941
46	15	\N	f	358	942
46	6	\N	f	359	943
46	7	\N	f	359	944
46	8	\N	f	359	945
46	9	\N	f	359	946
46	1	\N	f	360	947
46	2	\N	f	360	948
46	3	\N	f	360	949
46	4	\N	f	360	950
46	5	\N	f	360	951
49	32	\N	f	386	1031
49	33	\N	f	386	1032
49	34	\N	f	386	1033
49	35	\N	f	386	1034
49	25	\N	f	387	1035
47	32	\N	f	364	959
47	33	\N	f	364	960
47	34	\N	f	364	961
47	35	\N	f	364	962
47	25	\N	f	365	963
47	26	\N	f	365	964
47	27	\N	f	365	965
47	45	\N	f	365	966
47	23	\N	t	366	967
47	19	\N	f	367	968
47	20	\N	f	367	969
47	21	\N	f	367	970
47	22	\N	f	367	971
47	16	\N	f	368	972
47	17	\N	f	368	973
47	18	\N	f	368	974
47	28	\N	f	369	975
47	29	\N	f	369	976
47	31	\N	f	369	977
47	10	\N	f	370	978
47	11	\N	f	370	979
47	12	\N	f	370	980
47	13	\N	f	370	981
47	14	\N	f	370	982
47	15	\N	f	370	983
47	6	\N	f	371	984
47	7	\N	f	371	985
47	8	\N	f	371	986
47	9	\N	f	371	987
47	1	\N	f	372	990
47	2	\N	f	372	991
47	3	\N	f	372	992
47	4	\N	f	372	993
47	5	\N	f	372	994
48	32	\N	f	375	996
48	33	\N	f	375	997
48	34	\N	f	375	998
48	35	\N	f	375	999
48	25	\N	f	376	1000
48	26	\N	f	376	1001
48	27	\N	f	376	1002
48	45	\N	f	376	1003
48	23	\N	t	377	1004
48	19	\N	f	378	1005
48	20	\N	f	378	1006
48	21	\N	f	378	1007
48	22	\N	f	378	1008
48	16	\N	f	379	1009
48	17	\N	f	379	1010
48	18	\N	f	379	1011
48	28	\N	f	380	1012
48	29	\N	f	380	1013
48	31	\N	f	380	1014
48	10	\N	f	381	1015
48	11	\N	f	381	1016
48	12	\N	f	381	1017
48	13	\N	f	381	1018
48	14	\N	f	381	1019
48	15	\N	f	381	1020
48	6	\N	f	382	1021
48	7	\N	f	382	1022
48	8	\N	f	382	1023
48	9	\N	f	382	1024
48	1	\N	f	383	1025
48	2	\N	f	383	1026
48	3	\N	f	383	1027
48	4	\N	f	383	1028
48	5	\N	f	383	1029
49	26	\N	f	387	1036
49	27	\N	f	387	1037
49	45	\N	f	387	1038
49	23	\N	t	388	1039
49	19	\N	f	389	1040
49	20	\N	f	389	1041
49	21	\N	f	389	1042
49	22	\N	f	389	1043
49	16	\N	f	390	1044
49	17	\N	f	390	1045
49	18	\N	f	390	1046
49	28	\N	f	391	1047
49	29	\N	f	391	1048
49	31	\N	f	391	1049
49	10	\N	f	392	1050
49	11	\N	f	392	1051
49	12	\N	f	392	1052
49	13	\N	f	392	1053
49	14	\N	f	392	1054
49	15	\N	f	392	1055
49	6	\N	f	393	1056
49	7	\N	t	393	1057
49	8	\N	t	393	1058
49	9	\N	t	393	1059
49	4	\N	f	394	1063
49	5	\N	f	394	1064
49	1	\N	t	394	1060
49	2	\N	t	394	1061
49	3	\N	t	394	1062
\.


--
-- Name: law_enfocement_handbook_actions_handbook_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enfocement_handbook_actions_handbook_action_id_seq', 1064, true);


--
-- Data for Name: law_enforcement_action_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enforcement_action_categories (category_id, name, action_selection_type, description) FROM stdin;
11	Response Time	1	\N
5	User notification	1	This indicates whether an organization will notify persons who are affected by government agencies making requests for information pertaining to those persons.
10	Cost reimbursement	1	This indicates whether an organization will seek compensation for responding to government agencies' requests
8	Description of our services	3	This is a narrative box wherein organizations can explain the kinds of services that they provide to customers and subscribers
7	Policy on emergency requests	2	Organizations can identify how they will receive emergency requests from government agencies. Narrative that accompanies each option could include: specific contact information; time to respond to a request using the relevant mode of communication; and the time it will take an organization to respond.
6	How we respond to international requests	1	Organizations have the option to respond to international requests if they are a purely-Canadian organization. Select the option that indicates how your organization responds to international requests.
4	Required contact information	2	Organizations should note what information requesting government officials are expected to include with their requests.
3	Types of organizational disclosures	2	While organizations must be responsive to binding orders they may decide whether they will also sometimes voluntarily disclose information when not otherwise obliged to.
2	How should requests be sent to our organization?	2	Organizations should indicate what methods they would like to receive requests. We suggest that relevant contact information be added for each mode of communication your organization is responsive to in the narrative window associated with each choice.
\.


--
-- Name: law_enforcement_action_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enforcement_action_categories_category_id_seq', 21, true);


--
-- Data for Name: law_enforcement_actions; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enforcement_actions (action_id, category_id, name, narrative, narrative_label, inclusion_status_default) FROM stdin;
2	2	Phone	asdf	\N	\N
3	2	Email	test	\N	\N
4	2	Certified Mail	test	\N	\N
5	2	Courier	asdf	asdf	\N
11	4	Requesting Agency Officer Name / badge ID	asdfasd	\N	\N
12	4	Requesting Agent's email address	asdfasdf	\N	\N
13	4	Requesting Agent's Phone Contact	asdfasdf	\N	\N
14	4	Requesting Agency's Mailing Address	asdfasd	\N	\N
15	4	Requested Response Date	asdfasd	\N	\N
10	4	Requesting Agency Name	test	\N	\N
16	6	Accept	asdf	\N	\N
17	6	Reject	asdf	\N	\N
18	6	Require MLAT	asdf	\N	\N
19	7	Require Emergency Contact Letter	asdfasdf	\N	\N
20	7	Phone	asdf	\N	\N
21	7	Fax	adfgadfg	\N	\N
22	7	Email	asdf	\N	\N
23	8	Service provided	asdf	\N	\N
25	10	Will seek	asdf	\N	\N
26	10	Will sometimes seek	asdf	\N	\N
27	10	Will not seek	asdfasdf	\N	\N
28	5	Yes	asdf	\N	\N
29	5	No	asdf	\N	\N
31	5	Sometimes	asdf	\N	\N
1	2	Fax	Blah	\N	\N
32	11	asdfasdf	asdfasdfasdf	\N	\N
33	11	asdfasdf	asd asdfasdf	\N	\N
34	11	asdfasdf	asdf asdfasd	\N	\N
35	11	asdfasd	asd fasdfasdfasdf	\N	\N
45	10	idk	??	\N	\N
7	3	Government statutory / requirement letters		\N	t
8	3	Court orders		\N	t
9	3	Emergency requests		\N	t
6	3	Non-Obligatory Requests		\N	\N
\.


--
-- Name: law_enforcement_actions_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enforcement_actions_action_id_seq', 52, true);


--
-- Data for Name: law_enforcement_handbooks; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enforcement_handbooks (handbook_id, inclusion_status, complete_status, narrative, date_updated, date_updated_inclusion_status, transparency_report_id) FROM stdin;
4	t	f	dfgdsgsdfg	\N	\N	\N
5	t	f	dfgdsgsdfg	\N	\N	\N
6	t	f	dfgdsgsdfg	\N	\N	\N
8	t	f	asdfasdf	\N	\N	\N
10	t	f	asDasd	\N	\N	\N
7	t	f	dfgdsgsdfg	\N	\N	\N
11	t	f	asdfasdf	\N	\N	\N
12	t	f	asdfasdf	\N	\N	\N
13	t	f	dsrsfgh	\N	\N	\N
14	\N	\N	\N	\N	\N	\N
25	\N	\N	\N	\N	\N	\N
24	\N	\N	These are our guidlines.	\N	\N	\N
23	\N	\N	asdf asd fasdf asdf asdf	\N	\N	\N
22	\N	\N	\N	\N	\N	\N
21	\N	\N	sdfg	\N	\N	\N
19	\N	\N	\N	\N	\N	\N
20	\N	\N	\N	\N	\N	\N
18	\N	\N	\N	\N	\N	\N
17	\N	\N	\N	\N	\N	\N
16	\N	\N	\N	\N	\N	\N
15	\N	\N	\N	\N	\N	\N
45	\N	\N	\N	\N	\N	69
46	\N	\N	\N	2016-06-18	\N	70
47	t	t	\N	2016-06-18	\N	72
48	\N	\N	\N	2016-06-19	\N	73
49	\N	\N	asdf asdf!!	2016-06-19	\N	74
\.


--
-- Name: law_enforcement_handbooks_handbook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enforcement_handbooks_handbook_id_seq', 49, true);


--
-- Data for Name: transparency_reports; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY transparency_reports (report_id, publication_status, complete_status, publication_date, report_period_start, report_period_end, author_name, date_updated) FROM stdin;
70	\N	\N	2016-06-30	2015-01-01	2015-12-31	andfrew	2016-06-18
69	\N	\N	2016-06-02	2016-06-01	2016-06-09	Andrew	2016-06-18
71	\N	\N	2016-06-03	2016-06-01	2016-06-02	asdfasdf	2016-06-18
72	\N	t	2016-06-03	2016-06-01	2016-06-02	sdf asdfasdf	2016-06-18
73	\N	f	2016-06-01	2016-06-01	2016-06-16	Test Person	2016-06-19
74	\N	f	2016-06-07	2016-06-01	2016-06-23	test	2016-06-19
\.


--
-- Name: transparency_reports_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('transparency_reports_report_id_seq', 74, true);


--
-- Data for Name: type_disclosure_responses; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY type_disclosure_responses (response_id, disclosure_id, count, type_disclosure_id) FROM stdin;
9	194	0	1529
8	194	0	1530
7	194	0	1531
6	194	0	1532
5	194	0	1533
4	194	0	1534
3	194	0	1535
2	194	0	1536
9	195	0	1537
8	195	0	1538
7	195	0	1539
6	195	0	1540
5	195	0	1541
4	195	0	1542
3	195	0	1543
2	195	0	1544
9	196	0	1545
8	196	0	1546
7	196	0	1547
6	196	0	1548
5	196	0	1549
4	196	0	1550
3	196	0	1551
2	196	0	1552
9	197	0	1553
8	197	0	1554
7	197	0	1555
6	197	0	1556
5	197	0	1557
4	197	0	1558
3	197	0	1559
2	197	0	1560
9	198	0	1561
8	198	0	1562
7	198	0	1563
6	198	0	1564
5	198	0	1565
4	198	0	1566
3	198	0	1567
2	198	0	1568
9	199	0	1569
8	199	0	1570
7	199	0	1571
6	199	0	1572
5	199	0	1573
4	199	0	1574
3	199	0	1575
2	199	0	1576
9	200	0	1577
8	200	0	1578
7	200	0	1579
6	200	0	1580
5	200	0	1581
4	200	0	1582
3	200	0	1583
2	200	0	1584
9	201	0	1585
8	201	0	1586
7	201	0	1587
6	201	0	1588
5	201	0	1589
4	201	0	1590
3	201	0	1591
2	201	0	1592
9	202	0	1593
8	202	0	1594
7	202	0	1595
6	202	0	1596
5	202	0	1597
4	202	0	1598
3	202	0	1599
2	202	0	1600
9	203	0	1601
8	203	0	1602
7	203	0	1603
6	203	0	1604
5	203	0	1605
4	203	0	1606
3	203	0	1607
2	203	0	1608
9	204	0	1609
8	204	0	1610
7	204	0	1611
6	204	0	1612
5	204	0	1613
4	204	0	1614
3	204	0	1615
2	204	0	1616
9	205	0	1617
8	205	0	1618
7	205	0	1619
6	205	0	1620
5	205	0	1621
4	205	0	1622
3	205	0	1623
2	205	0	1624
9	207	0	1633
8	207	0	1634
7	207	0	1635
6	207	0	1636
5	207	0	1637
4	207	0	1638
3	207	0	1639
2	207	0	1640
9	208	0	1641
8	208	0	1642
7	208	0	1643
6	208	0	1644
5	208	0	1645
4	208	0	1646
3	208	0	1647
2	208	0	1648
9	209	0	1649
8	209	0	1650
7	209	0	1651
6	209	0	1652
5	209	0	1653
4	209	0	1654
3	209	0	1655
2	209	0	1656
9	210	0	1657
8	210	0	1658
7	210	0	1659
6	210	0	1660
5	210	0	1661
4	210	0	1662
3	210	0	1663
2	210	0	1664
9	211	0	1665
8	211	0	1666
7	211	0	1667
6	211	0	1668
5	211	0	1669
4	211	0	1670
3	211	0	1671
2	211	0	1672
9	212	0	1673
8	212	0	1674
7	212	0	1675
6	212	0	1676
5	212	0	1677
4	212	0	1678
3	212	0	1679
2	212	0	1680
9	213	0	1681
8	213	0	1682
7	213	0	1683
6	213	0	1684
5	213	0	1685
4	213	0	1686
3	213	0	1687
2	213	0	1688
9	214	0	1689
8	214	0	1690
7	214	0	1691
6	214	0	1692
5	214	0	1693
4	214	0	1694
3	214	0	1695
2	214	0	1696
9	215	0	1697
8	215	0	1698
7	215	0	1699
6	215	0	1700
5	215	0	1701
4	215	0	1702
3	215	0	1703
2	215	0	1704
9	216	0	1705
8	216	0	1706
7	216	0	1707
6	216	0	1708
5	216	0	1709
4	216	0	1710
3	216	0	1711
2	216	0	1712
9	217	0	1713
8	217	0	1714
7	217	0	1715
6	217	0	1716
5	217	0	1717
4	217	0	1718
3	217	0	1719
2	217	0	1720
9	218	0	1721
8	218	0	1722
7	218	0	1723
6	218	0	1724
5	218	0	1725
4	218	0	1726
3	218	0	1727
2	218	0	1728
9	219	0	1729
8	219	0	1730
7	219	0	1731
6	219	0	1732
5	219	0	1733
4	219	0	1734
3	219	0	1735
2	219	0	1736
9	220	0	1737
8	220	0	1738
7	220	0	1739
6	220	0	1740
5	220	0	1741
4	220	0	1742
3	220	0	1743
2	220	0	1744
9	221	0	1745
8	221	0	1746
7	221	0	1747
6	221	0	1748
5	221	0	1749
4	221	0	1750
3	221	0	1751
2	221	0	1752
9	222	0	1753
8	222	0	1754
7	222	0	1755
6	222	0	1756
5	222	0	1757
4	222	0	1758
3	222	0	1759
2	222	0	1760
9	223	0	1761
8	223	0	1762
7	223	0	1763
6	223	0	1764
5	223	0	1765
4	223	0	1766
3	223	0	1767
2	223	0	1768
9	224	0	1769
8	224	0	1770
7	224	0	1771
6	224	0	1772
5	224	0	1773
4	224	0	1774
3	224	0	1775
2	224	0	1776
9	225	0	1777
8	225	0	1778
7	225	0	1779
6	225	0	1780
5	225	0	1781
4	225	0	1782
3	225	0	1783
2	225	0	1784
9	226	0	1785
8	226	0	1786
7	226	0	1787
6	226	0	1788
5	226	0	1789
4	226	0	1790
3	226	0	1791
2	226	0	1792
9	227	0	1793
8	227	0	1794
7	227	0	1795
6	227	0	1796
5	227	0	1797
4	227	0	1798
3	227	0	1799
2	227	0	1800
9	228	0	1801
8	228	0	1802
7	228	0	1803
6	228	0	1804
5	228	0	1805
4	228	0	1806
3	228	0	1807
2	228	0	1808
9	229	0	1809
8	229	0	1810
7	229	0	1811
6	229	0	1812
5	229	0	1813
4	229	0	1814
3	229	0	1815
2	229	0	1816
9	230	0	1817
8	230	0	1818
7	230	0	1819
6	230	0	1820
5	230	0	1821
4	230	0	1822
3	230	0	1823
2	230	0	1824
9	231	0	1825
8	231	0	1826
7	231	0	1827
6	231	0	1828
5	231	0	1829
4	231	0	1830
3	231	0	1831
2	231	0	1832
9	232	0	1833
8	232	0	1834
7	232	0	1835
6	232	0	1836
5	232	0	1837
4	232	0	1838
3	232	0	1839
9	233	0	1841
8	233	0	1842
7	233	0	1843
6	233	0	1844
5	233	0	1845
4	233	0	1846
3	233	0	1847
2	233	0	1848
9	234	0	1849
8	234	0	1850
7	234	0	1851
6	234	0	1852
5	234	0	1853
4	234	0	1854
3	234	0	1855
2	234	0	1856
9	235	0	1857
8	235	0	1858
7	235	0	1859
6	235	0	1860
5	235	0	1861
4	235	0	1862
3	235	0	1863
2	235	0	1864
9	236	0	1865
8	236	0	1866
7	236	0	1867
6	236	0	1868
5	236	0	1869
4	236	0	1870
3	236	0	1871
9	237	0	1873
8	237	0	1874
7	237	0	1875
6	237	0	1876
5	237	0	1877
4	237	0	1878
3	237	0	1879
2	237	0	1880
9	238	0	1881
8	238	0	1882
7	238	0	1883
6	238	0	1884
5	238	0	1885
4	238	0	1886
3	238	0	1887
9	239	0	1889
8	239	0	1890
7	239	0	1891
6	239	0	1892
5	239	0	1893
4	239	0	1894
3	239	0	1895
2	239	0	1896
9	240	0	1897
2	238	12	1888
2	232	123	1840
8	240	0	1898
7	240	0	1899
6	240	0	1900
5	240	0	1901
4	240	0	1902
3	240	0	1903
2	240	0	1904
9	241	0	1905
8	241	0	1906
7	241	0	1907
6	241	0	1908
5	241	0	1909
4	241	0	1910
3	241	0	1911
2	241	0	1912
9	242	0	1913
8	242	0	1914
7	242	0	1915
6	242	0	1916
5	242	0	1917
4	242	0	1918
3	242	0	1919
2	242	0	1920
2	236	21312	1872
\.


--
-- Name: type_disclosure_responses_type_disclosure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('type_disclosure_responses_type_disclosure_id_seq', 1920, true);


--
-- Name: data_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_categories
    ADD CONSTRAINT data_categories_pkey PRIMARY KEY (category_id);


--
-- Name: data_items_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_items
    ADD CONSTRAINT data_items_pkey PRIMARY KEY (item_id);


--
-- Name: data_retention_guide_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_retention_guide_categories
    ADD CONSTRAINT data_retention_guide_categories_pkey PRIMARY KEY (guide_category_id);


--
-- Name: data_retention_guide_items_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_pkey PRIMARY KEY (guide_item_id);


--
-- Name: data_retention_guides_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_retention_guides
    ADD CONSTRAINT data_retention_guides_pkey PRIMARY KEY (guide_id);


--
-- Name: government_request_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_categories
    ADD CONSTRAINT government_request_categories_pkey PRIMARY KEY (category_id);


--
-- Name: government_request_report_type_disclosures_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_report_type_disclosures
    ADD CONSTRAINT government_request_report_type_disclosures_pkey PRIMARY KEY (disclosure_id);


--
-- Name: government_request_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_responses
    ADD CONSTRAINT government_request_responses_pkey PRIMARY KEY (response_id);


--
-- Name: government_request_types_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_types
    ADD CONSTRAINT government_request_types_pkey PRIMARY KEY (type_id);


--
-- Name: government_requests_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_requests_reports
    ADD CONSTRAINT government_requests_reports_pkey PRIMARY KEY (report_id);


--
-- Name: law_enfocement_handbook_action_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories
    ADD CONSTRAINT law_enfocement_handbook_action_categories_pkey PRIMARY KEY (handbook_category_id);


--
-- Name: law_enfocement_handbook_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_pkey PRIMARY KEY (handbook_action_id);


--
-- Name: law_enforcement_action_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enforcement_action_categories
    ADD CONSTRAINT law_enforcement_action_categories_pkey PRIMARY KEY (category_id);


--
-- Name: law_enforcement_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enforcement_actions
    ADD CONSTRAINT law_enforcement_actions_pkey PRIMARY KEY (action_id);


--
-- Name: law_enforcement_handbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enforcement_handbooks
    ADD CONSTRAINT law_enforcement_handbooks_pkey PRIMARY KEY (handbook_id);


--
-- Name: transparency_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY transparency_reports
    ADD CONSTRAINT transparency_reports_pkey PRIMARY KEY (report_id);


--
-- Name: type_disclosure_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY type_disclosure_responses
    ADD CONSTRAINT type_disclosure_responses_pkey PRIMARY KEY (type_disclosure_id);


--
-- Name: data_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_items
    ADD CONSTRAINT data_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES data_categories(category_id) ON DELETE CASCADE;


--
-- Name: data_retention_guide_categories_guide_data_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_categories
    ADD CONSTRAINT data_retention_guide_categories_guide_data_category_id_fkey FOREIGN KEY (guide_data_category_id) REFERENCES data_categories(category_id) ON DELETE CASCADE;


--
-- Name: data_retention_guide_categories_guide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_categories
    ADD CONSTRAINT data_retention_guide_categories_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES data_retention_guides(guide_id) ON DELETE CASCADE;


--
-- Name: data_retention_guide_items_guide_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_guide_category_id_fkey FOREIGN KEY (guide_category_id) REFERENCES data_retention_guide_categories(guide_category_id) ON DELETE CASCADE;


--
-- Name: data_retention_guide_items_guide_data_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_guide_data_item_id_fkey FOREIGN KEY (guide_data_item_id) REFERENCES data_items(item_id) ON DELETE CASCADE;


--
-- Name: data_retention_guide_items_guide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES data_retention_guides(guide_id) ON DELETE CASCADE;


--
-- Name: data_retention_guides_transparency_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guides
    ADD CONSTRAINT data_retention_guides_transparency_report_id_fkey FOREIGN KEY (transparency_report_id) REFERENCES transparency_reports(report_id) ON DELETE CASCADE;


--
-- Name: government_request_report_type_disclosur_request_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_report_type_disclosures
    ADD CONSTRAINT government_request_report_type_disclosur_request_report_id_fkey FOREIGN KEY (request_report_id) REFERENCES government_requests_reports(report_id) ON DELETE CASCADE;


--
-- Name: government_request_report_type_disclosures_request_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_report_type_disclosures
    ADD CONSTRAINT government_request_report_type_disclosures_request_type_id_fkey FOREIGN KEY (request_type_id) REFERENCES government_request_types(type_id) ON DELETE CASCADE;


--
-- Name: government_request_types_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_types
    ADD CONSTRAINT government_request_types_category_id_fkey FOREIGN KEY (category_id) REFERENCES government_request_categories(category_id) ON DELETE CASCADE;


--
-- Name: government_requests_reports_transparency_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_requests_reports
    ADD CONSTRAINT government_requests_reports_transparency_report_id_fkey FOREIGN KEY (transparency_report_id) REFERENCES transparency_reports(report_id) ON DELETE CASCADE;


--
-- Name: law_enfocement_handbook_action_categori_action_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories
    ADD CONSTRAINT law_enfocement_handbook_action_categori_action_category_id_fkey FOREIGN KEY (action_category_id) REFERENCES law_enforcement_action_categories(category_id) ON DELETE CASCADE;


--
-- Name: law_enfocement_handbook_action_categories_handbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories
    ADD CONSTRAINT law_enfocement_handbook_action_categories_handbook_id_fkey FOREIGN KEY (handbook_id) REFERENCES law_enforcement_handbooks(handbook_id) ON DELETE CASCADE;


--
-- Name: law_enfocement_handbook_actions_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_action_id_fkey FOREIGN KEY (action_id) REFERENCES law_enforcement_actions(action_id) ON DELETE CASCADE;


--
-- Name: law_enfocement_handbook_actions_handbook_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_handbook_category_id_fkey FOREIGN KEY (handbook_category_id) REFERENCES law_enfocement_handbook_action_categories(handbook_category_id) ON DELETE CASCADE;


--
-- Name: law_enfocement_handbook_actions_handbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_handbook_id_fkey FOREIGN KEY (handbook_id) REFERENCES law_enforcement_handbooks(handbook_id) ON DELETE CASCADE;


--
-- Name: law_enforcement_actions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_actions
    ADD CONSTRAINT law_enforcement_actions_category_id_fkey FOREIGN KEY (category_id) REFERENCES law_enforcement_action_categories(category_id) ON DELETE CASCADE;


--
-- Name: law_enforcement_handbooks_transparency_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_handbooks
    ADD CONSTRAINT law_enforcement_handbooks_transparency_report_id_fkey FOREIGN KEY (transparency_report_id) REFERENCES transparency_reports(report_id) ON DELETE CASCADE;


--
-- Name: type_disclosure_responses_disclosure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY type_disclosure_responses
    ADD CONSTRAINT type_disclosure_responses_disclosure_id_fkey FOREIGN KEY (disclosure_id) REFERENCES government_request_report_type_disclosures(disclosure_id) ON DELETE CASCADE;


--
-- Name: type_disclosure_responses_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY type_disclosure_responses
    ADD CONSTRAINT type_disclosure_responses_response_id_fkey FOREIGN KEY (response_id) REFERENCES government_request_responses(response_id) ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

