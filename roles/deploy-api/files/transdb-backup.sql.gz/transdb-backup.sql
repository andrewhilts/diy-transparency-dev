--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.type_disclosure_responses DROP CONSTRAINT type_disclosure_responses_response_id_fkey;
ALTER TABLE ONLY public.type_disclosure_responses DROP CONSTRAINT type_disclosure_responses_disclosure_id_fkey;
ALTER TABLE ONLY public.law_enforcement_handbooks DROP CONSTRAINT law_enforcement_handbooks_transparency_report_id_fkey;
ALTER TABLE ONLY public.law_enforcement_actions DROP CONSTRAINT law_enforcement_actions_category_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_handbook_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_handbook_category_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_action_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_action_categories DROP CONSTRAINT law_enfocement_handbook_action_categories_handbook_id_fkey;
ALTER TABLE ONLY public.law_enfocement_handbook_action_categories DROP CONSTRAINT law_enfocement_handbook_action_categori_action_category_id_fkey;
ALTER TABLE ONLY public.government_requests_reports DROP CONSTRAINT government_requests_reports_transparency_report_id_fkey;
ALTER TABLE ONLY public.government_request_types DROP CONSTRAINT government_request_types_category_id_fkey;
ALTER TABLE ONLY public.government_request_report_type_disclosures DROP CONSTRAINT government_request_report_type_disclosures_request_type_id_fkey;
ALTER TABLE ONLY public.government_request_report_type_disclosures DROP CONSTRAINT government_request_report_type_disclosur_request_report_id_fkey;
ALTER TABLE ONLY public.data_retention_guides DROP CONSTRAINT data_retention_guides_transparency_report_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_guide_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_guide_data_item_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_guide_category_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_categories DROP CONSTRAINT data_retention_guide_categories_guide_id_fkey;
ALTER TABLE ONLY public.data_retention_guide_categories DROP CONSTRAINT data_retention_guide_categories_guide_data_category_id_fkey;
ALTER TABLE ONLY public.data_items DROP CONSTRAINT data_items_category_id_fkey;
ALTER TABLE ONLY public.type_disclosure_responses DROP CONSTRAINT type_disclosure_responses_pkey;
ALTER TABLE ONLY public.transparency_reports DROP CONSTRAINT transparency_reports_pkey;
ALTER TABLE ONLY public.law_enforcement_handbooks DROP CONSTRAINT law_enforcement_handbooks_pkey;
ALTER TABLE ONLY public.law_enforcement_actions DROP CONSTRAINT law_enforcement_actions_pkey;
ALTER TABLE ONLY public.law_enforcement_action_categories DROP CONSTRAINT law_enforcement_action_categories_pkey;
ALTER TABLE ONLY public.law_enfocement_handbook_actions DROP CONSTRAINT law_enfocement_handbook_actions_pkey;
ALTER TABLE ONLY public.law_enfocement_handbook_action_categories DROP CONSTRAINT law_enfocement_handbook_action_categories_pkey;
ALTER TABLE ONLY public.government_requests_reports DROP CONSTRAINT government_requests_reports_pkey;
ALTER TABLE ONLY public.government_request_types DROP CONSTRAINT government_request_types_pkey;
ALTER TABLE ONLY public.government_request_responses DROP CONSTRAINT government_request_responses_pkey;
ALTER TABLE ONLY public.government_request_report_type_disclosures DROP CONSTRAINT government_request_report_type_disclosures_pkey;
ALTER TABLE ONLY public.government_request_categories DROP CONSTRAINT government_request_categories_pkey;
ALTER TABLE ONLY public.data_retention_guides DROP CONSTRAINT data_retention_guides_pkey;
ALTER TABLE ONLY public.data_retention_guide_items DROP CONSTRAINT data_retention_guide_items_pkey;
ALTER TABLE ONLY public.data_retention_guide_categories DROP CONSTRAINT data_retention_guide_categories_pkey;
ALTER TABLE ONLY public.data_items DROP CONSTRAINT data_items_pkey;
ALTER TABLE ONLY public.data_categories DROP CONSTRAINT data_categories_pkey;
ALTER TABLE public.type_disclosure_responses ALTER COLUMN type_disclosure_id DROP DEFAULT;
ALTER TABLE public.transparency_reports ALTER COLUMN report_id DROP DEFAULT;
ALTER TABLE public.law_enforcement_handbooks ALTER COLUMN handbook_id DROP DEFAULT;
ALTER TABLE public.law_enforcement_actions ALTER COLUMN action_id DROP DEFAULT;
ALTER TABLE public.law_enforcement_action_categories ALTER COLUMN category_id DROP DEFAULT;
ALTER TABLE public.law_enfocement_handbook_actions ALTER COLUMN handbook_action_id DROP DEFAULT;
ALTER TABLE public.law_enfocement_handbook_action_categories ALTER COLUMN handbook_category_id DROP DEFAULT;
ALTER TABLE public.government_requests_reports ALTER COLUMN report_id DROP DEFAULT;
ALTER TABLE public.government_request_types ALTER COLUMN type_id DROP DEFAULT;
ALTER TABLE public.government_request_responses ALTER COLUMN response_id DROP DEFAULT;
ALTER TABLE public.government_request_report_type_disclosures ALTER COLUMN disclosure_id DROP DEFAULT;
ALTER TABLE public.government_request_categories ALTER COLUMN category_id DROP DEFAULT;
ALTER TABLE public.data_retention_guides ALTER COLUMN guide_id DROP DEFAULT;
ALTER TABLE public.data_retention_guide_items ALTER COLUMN guide_item_id DROP DEFAULT;
ALTER TABLE public.data_retention_guide_categories ALTER COLUMN guide_category_id DROP DEFAULT;
ALTER TABLE public.data_items ALTER COLUMN item_id DROP DEFAULT;
ALTER TABLE public.data_categories ALTER COLUMN category_id DROP DEFAULT;
DROP SEQUENCE public.type_disclosure_responses_type_disclosure_id_seq;
DROP TABLE public.type_disclosure_responses;
DROP SEQUENCE public.transparency_reports_report_id_seq;
DROP TABLE public.transparency_reports;
DROP SEQUENCE public.law_enforcement_handbooks_handbook_id_seq;
DROP TABLE public.law_enforcement_handbooks;
DROP SEQUENCE public.law_enforcement_actions_action_id_seq;
DROP TABLE public.law_enforcement_actions;
DROP SEQUENCE public.law_enforcement_action_categories_category_id_seq;
DROP TABLE public.law_enforcement_action_categories;
DROP SEQUENCE public.law_enfocement_handbook_actions_handbook_action_id_seq;
DROP TABLE public.law_enfocement_handbook_actions;
DROP SEQUENCE public.law_enfocement_handbook_action_categor_handbook_category_id_seq;
DROP TABLE public.law_enfocement_handbook_action_categories;
DROP SEQUENCE public.government_requests_reports_report_id_seq;
DROP TABLE public.government_requests_reports;
DROP SEQUENCE public.government_request_types_type_id_seq;
DROP TABLE public.government_request_types;
DROP SEQUENCE public.government_request_responses_response_id_seq;
DROP TABLE public.government_request_responses;
DROP SEQUENCE public.government_request_report_type_disclosures_disclosure_id_seq;
DROP TABLE public.government_request_report_type_disclosures;
DROP SEQUENCE public.government_request_categories_category_id_seq;
DROP TABLE public.government_request_categories;
DROP SEQUENCE public.data_retention_guides_guide_id_seq;
DROP TABLE public.data_retention_guides;
DROP SEQUENCE public.data_retention_guide_items_guide_item_id_seq;
DROP TABLE public.data_retention_guide_items;
DROP SEQUENCE public.data_retention_guide_categories_guide_category_id_seq;
DROP TABLE public.data_retention_guide_categories;
DROP SEQUENCE public.data_items_item_id_seq;
DROP TABLE public.data_items;
DROP SEQUENCE public.data_categories_category_id_seq;
DROP TABLE public.data_categories;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: data_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_categories (
    category_id integer NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.data_categories OWNER TO transdb;

--
-- Name: data_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_categories_category_id_seq OWNER TO transdb;

--
-- Name: data_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_categories_category_id_seq OWNED BY data_categories.category_id;


--
-- Name: data_items; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_items (
    item_id integer NOT NULL,
    name character varying(255),
    description text,
    category_id integer
);


ALTER TABLE public.data_items OWNER TO transdb;

--
-- Name: data_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_items_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_items_item_id_seq OWNER TO transdb;

--
-- Name: data_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_items_item_id_seq OWNED BY data_items.item_id;


--
-- Name: data_retention_guide_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_retention_guide_categories (
    guide_id integer NOT NULL,
    guide_data_category_id integer NOT NULL,
    inclusion_status boolean,
    retention_status boolean,
    guide_category_id integer NOT NULL
);


ALTER TABLE public.data_retention_guide_categories OWNER TO transdb;

--
-- Name: data_retention_guide_categories_guide_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_retention_guide_categories_guide_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_retention_guide_categories_guide_category_id_seq OWNER TO transdb;

--
-- Name: data_retention_guide_categories_guide_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_retention_guide_categories_guide_category_id_seq OWNED BY data_retention_guide_categories.guide_category_id;


--
-- Name: data_retention_guide_items; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_retention_guide_items (
    guide_id integer NOT NULL,
    guide_data_item_id integer NOT NULL,
    narrative text,
    inclusion_status boolean,
    retention_status boolean,
    guide_item_id integer NOT NULL,
    guide_category_id integer
);


ALTER TABLE public.data_retention_guide_items OWNER TO transdb;

--
-- Name: data_retention_guide_items_guide_item_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_retention_guide_items_guide_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_retention_guide_items_guide_item_id_seq OWNER TO transdb;

--
-- Name: data_retention_guide_items_guide_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_retention_guide_items_guide_item_id_seq OWNED BY data_retention_guide_items.guide_item_id;


--
-- Name: data_retention_guides; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE data_retention_guides (
    guide_id integer NOT NULL,
    inclusion_status boolean,
    complete_status boolean,
    narrative text,
    transparency_report_id integer
);


ALTER TABLE public.data_retention_guides OWNER TO transdb;

--
-- Name: data_retention_guides_guide_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE data_retention_guides_guide_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.data_retention_guides_guide_id_seq OWNER TO transdb;

--
-- Name: data_retention_guides_guide_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE data_retention_guides_guide_id_seq OWNED BY data_retention_guides.guide_id;


--
-- Name: government_request_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_categories (
    category_id integer NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.government_request_categories OWNER TO transdb;

--
-- Name: government_request_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_categories_category_id_seq OWNER TO transdb;

--
-- Name: government_request_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_categories_category_id_seq OWNED BY government_request_categories.category_id;


--
-- Name: government_request_report_type_disclosures; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_report_type_disclosures (
    disclosure_id integer NOT NULL,
    request_report_id integer,
    request_type_id integer
);


ALTER TABLE public.government_request_report_type_disclosures OWNER TO transdb;

--
-- Name: government_request_report_type_disclosures_disclosure_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_report_type_disclosures_disclosure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_report_type_disclosures_disclosure_id_seq OWNER TO transdb;

--
-- Name: government_request_report_type_disclosures_disclosure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_report_type_disclosures_disclosure_id_seq OWNED BY government_request_report_type_disclosures.disclosure_id;


--
-- Name: government_request_responses; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_responses (
    response_id integer NOT NULL,
    name character varying(255),
    description text
);


ALTER TABLE public.government_request_responses OWNER TO transdb;

--
-- Name: government_request_responses_response_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_responses_response_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_responses_response_id_seq OWNER TO transdb;

--
-- Name: government_request_responses_response_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_responses_response_id_seq OWNED BY government_request_responses.response_id;


--
-- Name: government_request_types; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_request_types (
    type_id integer NOT NULL,
    category_id integer,
    name character varying(255),
    description text
);


ALTER TABLE public.government_request_types OWNER TO transdb;

--
-- Name: government_request_types_type_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_request_types_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_request_types_type_id_seq OWNER TO transdb;

--
-- Name: government_request_types_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_request_types_type_id_seq OWNED BY government_request_types.type_id;


--
-- Name: government_requests_reports; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE government_requests_reports (
    report_id integer NOT NULL,
    transparency_report_id integer,
    inclusion_status boolean,
    complete_status boolean,
    narrative text
);


ALTER TABLE public.government_requests_reports OWNER TO transdb;

--
-- Name: government_requests_reports_report_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE government_requests_reports_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.government_requests_reports_report_id_seq OWNER TO transdb;

--
-- Name: government_requests_reports_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE government_requests_reports_report_id_seq OWNED BY government_requests_reports.report_id;


--
-- Name: law_enfocement_handbook_action_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enfocement_handbook_action_categories (
    handbook_id integer NOT NULL,
    action_category_id integer NOT NULL,
    inclusion_status boolean,
    handbook_category_id integer NOT NULL
);


ALTER TABLE public.law_enfocement_handbook_action_categories OWNER TO transdb;

--
-- Name: law_enfocement_handbook_action_categor_handbook_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enfocement_handbook_action_categor_handbook_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enfocement_handbook_action_categor_handbook_category_id_seq OWNER TO transdb;

--
-- Name: law_enfocement_handbook_action_categor_handbook_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enfocement_handbook_action_categor_handbook_category_id_seq OWNED BY law_enfocement_handbook_action_categories.handbook_category_id;


--
-- Name: law_enfocement_handbook_actions; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enfocement_handbook_actions (
    handbook_id integer NOT NULL,
    action_id integer NOT NULL,
    narrative text,
    inclusion_status boolean,
    handbook_category_id integer,
    handbook_action_id integer NOT NULL
);


ALTER TABLE public.law_enfocement_handbook_actions OWNER TO transdb;

--
-- Name: law_enfocement_handbook_actions_handbook_action_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enfocement_handbook_actions_handbook_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enfocement_handbook_actions_handbook_action_id_seq OWNER TO transdb;

--
-- Name: law_enfocement_handbook_actions_handbook_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enfocement_handbook_actions_handbook_action_id_seq OWNED BY law_enfocement_handbook_actions.handbook_action_id;


--
-- Name: law_enforcement_action_categories; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enforcement_action_categories (
    category_id integer NOT NULL,
    name character varying(255),
    action_selection_type integer
);


ALTER TABLE public.law_enforcement_action_categories OWNER TO transdb;

--
-- Name: law_enforcement_action_categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enforcement_action_categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enforcement_action_categories_category_id_seq OWNER TO transdb;

--
-- Name: law_enforcement_action_categories_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enforcement_action_categories_category_id_seq OWNED BY law_enforcement_action_categories.category_id;


--
-- Name: law_enforcement_actions; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enforcement_actions (
    action_id integer NOT NULL,
    category_id integer,
    name character varying(255),
    narrative text,
    narrative_label character varying(255)
);


ALTER TABLE public.law_enforcement_actions OWNER TO transdb;

--
-- Name: law_enforcement_actions_action_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enforcement_actions_action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enforcement_actions_action_id_seq OWNER TO transdb;

--
-- Name: law_enforcement_actions_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enforcement_actions_action_id_seq OWNED BY law_enforcement_actions.action_id;


--
-- Name: law_enforcement_handbooks; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE law_enforcement_handbooks (
    handbook_id integer NOT NULL,
    inclusion_status boolean,
    complete_status boolean,
    narrative text,
    date_updated date,
    date_updated_inclusion_status boolean,
    transparency_report_id integer
);


ALTER TABLE public.law_enforcement_handbooks OWNER TO transdb;

--
-- Name: law_enforcement_handbooks_handbook_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE law_enforcement_handbooks_handbook_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.law_enforcement_handbooks_handbook_id_seq OWNER TO transdb;

--
-- Name: law_enforcement_handbooks_handbook_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE law_enforcement_handbooks_handbook_id_seq OWNED BY law_enforcement_handbooks.handbook_id;


--
-- Name: transparency_reports; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE transparency_reports (
    report_id integer NOT NULL,
    publication_status boolean,
    complete_status boolean,
    publication_date date,
    update_date date,
    report_period_start date,
    report_period_end date,
    author_name character varying(255)
);


ALTER TABLE public.transparency_reports OWNER TO transdb;

--
-- Name: transparency_reports_report_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE transparency_reports_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transparency_reports_report_id_seq OWNER TO transdb;

--
-- Name: transparency_reports_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE transparency_reports_report_id_seq OWNED BY transparency_reports.report_id;


--
-- Name: type_disclosure_responses; Type: TABLE; Schema: public; Owner: transdb; Tablespace: 
--

CREATE TABLE type_disclosure_responses (
    response_id integer NOT NULL,
    disclosure_id integer NOT NULL,
    count integer,
    type_disclosure_id integer NOT NULL
);


ALTER TABLE public.type_disclosure_responses OWNER TO transdb;

--
-- Name: type_disclosure_responses_type_disclosure_id_seq; Type: SEQUENCE; Schema: public; Owner: transdb
--

CREATE SEQUENCE type_disclosure_responses_type_disclosure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_disclosure_responses_type_disclosure_id_seq OWNER TO transdb;

--
-- Name: type_disclosure_responses_type_disclosure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: transdb
--

ALTER SEQUENCE type_disclosure_responses_type_disclosure_id_seq OWNED BY type_disclosure_responses.type_disclosure_id;


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_categories ALTER COLUMN category_id SET DEFAULT nextval('data_categories_category_id_seq'::regclass);


--
-- Name: item_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_items ALTER COLUMN item_id SET DEFAULT nextval('data_items_item_id_seq'::regclass);


--
-- Name: guide_category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_categories ALTER COLUMN guide_category_id SET DEFAULT nextval('data_retention_guide_categories_guide_category_id_seq'::regclass);


--
-- Name: guide_item_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items ALTER COLUMN guide_item_id SET DEFAULT nextval('data_retention_guide_items_guide_item_id_seq'::regclass);


--
-- Name: guide_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guides ALTER COLUMN guide_id SET DEFAULT nextval('data_retention_guides_guide_id_seq'::regclass);


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_categories ALTER COLUMN category_id SET DEFAULT nextval('government_request_categories_category_id_seq'::regclass);


--
-- Name: disclosure_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_report_type_disclosures ALTER COLUMN disclosure_id SET DEFAULT nextval('government_request_report_type_disclosures_disclosure_id_seq'::regclass);


--
-- Name: response_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_responses ALTER COLUMN response_id SET DEFAULT nextval('government_request_responses_response_id_seq'::regclass);


--
-- Name: type_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_types ALTER COLUMN type_id SET DEFAULT nextval('government_request_types_type_id_seq'::regclass);


--
-- Name: report_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_requests_reports ALTER COLUMN report_id SET DEFAULT nextval('government_requests_reports_report_id_seq'::regclass);


--
-- Name: handbook_category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories ALTER COLUMN handbook_category_id SET DEFAULT nextval('law_enfocement_handbook_action_categor_handbook_category_id_seq'::regclass);


--
-- Name: handbook_action_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions ALTER COLUMN handbook_action_id SET DEFAULT nextval('law_enfocement_handbook_actions_handbook_action_id_seq'::regclass);


--
-- Name: category_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_action_categories ALTER COLUMN category_id SET DEFAULT nextval('law_enforcement_action_categories_category_id_seq'::regclass);


--
-- Name: action_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_actions ALTER COLUMN action_id SET DEFAULT nextval('law_enforcement_actions_action_id_seq'::regclass);


--
-- Name: handbook_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_handbooks ALTER COLUMN handbook_id SET DEFAULT nextval('law_enforcement_handbooks_handbook_id_seq'::regclass);


--
-- Name: report_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY transparency_reports ALTER COLUMN report_id SET DEFAULT nextval('transparency_reports_report_id_seq'::regclass);


--
-- Name: type_disclosure_id; Type: DEFAULT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY type_disclosure_responses ALTER COLUMN type_disclosure_id SET DEFAULT nextval('type_disclosure_responses_type_disclosure_id_seq'::regclass);


--
-- Data for Name: data_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_categories (category_id, name, description) FROM stdin;
5	Personally Identifiable Information	\N
6	Content	\N
7	Transmission Data	\N
4	Subscriber Data	test test
\.


--
-- Name: data_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_categories_category_id_seq', 7, true);


--
-- Data for Name: data_items; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_items (item_id, name, description, category_id) FROM stdin;
5	Billing Info	test	4
7	Phone Number	test	4
8	Other	test	4
9	Username	test	4
11	IP Address	test	5
12	Websites visited	test	5
13	Websites visited (external)	test	5
14	Search history	test	5
15	Call logs	test	5
16	Messages between individual and organization	test	6
17	Messages between users	test	6
18	Content posted to service	test	6
19	Other	?	6
20	Web traffic logs	test	7
21	Call logs	test	7
22	Time and date of communications	test	7
23	Other	test	7
4	Address	tytes	4
6	Email Address	@	4
10	Geolocation	test	5
24	rtuyrty	rtyrty	4
\.


--
-- Name: data_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_items_item_id_seq', 24, true);


--
-- Data for Name: data_retention_guide_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_retention_guide_categories (guide_id, guide_data_category_id, inclusion_status, retention_status, guide_category_id) FROM stdin;
4	5	\N	\N	1
4	6	\N	\N	2
4	7	\N	\N	3
4	4	\N	\N	4
5	5	\N	\N	5
5	6	\N	\N	6
5	7	\N	\N	7
5	4	\N	\N	8
7	7	f	\N	11
7	4	f	\N	12
8	5	t	\N	13
8	7	t	\N	15
8	4	t	\N	16
8	6	f	\N	14
9	5	t	\N	17
9	6	t	\N	18
9	7	t	\N	19
9	4	t	\N	20
7	5	t	\N	9
7	6	t	\N	10
10	5	t	\N	21
10	6	t	\N	22
10	7	t	\N	23
10	4	t	\N	24
11	5	t	\N	25
11	7	t	\N	27
11	4	t	\N	28
11	6	f	\N	26
12	5	t	\N	29
12	6	t	\N	30
12	7	t	\N	31
12	4	t	\N	32
13	5	t	\N	33
13	6	t	\N	34
13	7	t	\N	35
13	4	t	\N	36
14	5	t	\N	37
14	6	t	\N	38
14	7	t	\N	39
14	4	t	\N	40
\.


--
-- Name: data_retention_guide_categories_guide_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_retention_guide_categories_guide_category_id_seq', 40, true);


--
-- Data for Name: data_retention_guide_items; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_retention_guide_items (guide_id, guide_data_item_id, narrative, inclusion_status, retention_status, guide_item_id, guide_category_id) FROM stdin;
4	10	\N	\N	\N	1	1
4	11	\N	\N	\N	2	1
4	12	\N	\N	\N	3	1
4	13	\N	\N	\N	4	1
4	14	\N	\N	\N	5	1
4	15	\N	\N	\N	6	1
4	16	\N	\N	\N	7	2
4	17	\N	\N	\N	8	2
4	18	\N	\N	\N	9	2
4	19	\N	\N	\N	10	2
4	20	\N	\N	\N	11	3
4	21	\N	\N	\N	12	3
4	22	\N	\N	\N	13	3
4	23	\N	\N	\N	14	3
4	5	\N	\N	\N	15	4
4	7	\N	\N	\N	16	4
4	8	\N	\N	\N	17	4
4	9	\N	\N	\N	18	4
4	4	\N	\N	\N	19	4
4	6	\N	\N	\N	20	4
5	10	\N	\N	\N	21	5
5	11	\N	\N	\N	22	5
5	12	\N	\N	\N	23	5
5	13	\N	\N	\N	24	5
5	14	\N	\N	\N	25	5
5	15	\N	\N	\N	26	5
5	16	\N	\N	\N	27	6
5	17	\N	\N	\N	28	6
5	18	\N	\N	\N	29	6
5	19	\N	\N	\N	30	6
5	20	\N	\N	\N	31	7
5	21	\N	\N	\N	32	7
5	22	\N	\N	\N	33	7
5	23	\N	\N	\N	34	7
5	5	\N	\N	\N	35	8
5	7	\N	\N	\N	36	8
5	8	\N	\N	\N	37	8
5	9	\N	\N	\N	38	8
5	4	\N	\N	\N	39	8
5	6	\N	\N	\N	40	8
7	12	\N	t	\N	43	9
7	13	\N	t	\N	44	9
7	14	\N	t	\N	45	9
7	15	\N	t	\N	46	9
7	16	\N	t	\N	47	10
7	19	\N	t	\N	50	10
7	20	\N	t	\N	51	11
7	22	\N	t	\N	53	11
7	23	\N	t	\N	54	11
7	9	\N	t	\N	58	12
7	4	\N	t	\N	59	12
7	6	\N	t	\N	60	12
7	18	\N	f	\N	49	10
7	21	\N	f	\N	52	11
7	5	\N	f	\N	55	12
7	17	\N	f	\N	48	10
7	8	\N	f	\N	57	12
7	10	\N	t	\N	41	9
7	11	\N	t	\N	42	9
7	7	\N	t	\N	56	12
8	11	\N	t	\N	62	13
8	12	\N	t	\N	63	13
8	13	\N	t	\N	64	13
8	14	\N	t	\N	65	13
8	15	\N	t	\N	66	13
8	18	\N	t	\N	69	14
8	19	\N	t	\N	70	14
8	20	\N	t	\N	71	15
8	21	\N	t	\N	72	15
8	22	\N	t	\N	73	15
8	23	\N	t	\N	74	15
8	5	\N	t	\N	75	16
8	7	\N	t	\N	76	16
8	8	\N	t	\N	77	16
8	9	\N	t	\N	78	16
8	4	\N	t	\N	79	16
8	6	\N	t	\N	80	16
8	10	\N	f	\N	61	13
8	16	\N	f	\N	67	14
8	17	\N	f	\N	68	14
12	11	\N	t	\N	144	29
9	12	\N	t	\N	82	17
9	13	\N	t	\N	83	17
9	14	\N	t	\N	84	17
9	15	\N	t	\N	85	17
9	10	\N	t	\N	86	17
9	17	\N	t	\N	88	18
9	18	\N	t	\N	89	18
9	19	\N	t	\N	90	18
9	20	\N	t	\N	91	19
9	21	\N	t	\N	92	19
9	22	\N	t	\N	93	19
9	23	\N	t	\N	94	19
9	5	\N	t	\N	95	20
9	7	\N	t	\N	96	20
9	8	\N	t	\N	97	20
9	9	\N	t	\N	98	20
9	4	\N	t	\N	99	20
9	6	\N	t	\N	100	20
9	24	\N	t	\N	101	20
9	11	\N	f	\N	81	17
9	16	\N	f	\N	87	18
10	11	\N	t	\N	102	21
10	12	\N	t	\N	103	21
10	13	\N	t	\N	104	21
10	14	\N	t	\N	105	21
10	15	\N	t	\N	106	21
10	10	\N	t	\N	107	21
10	16	\N	t	\N	108	22
10	17	\N	t	\N	109	22
10	18	\N	t	\N	110	22
10	19	\N	t	\N	111	22
10	20	\N	t	\N	112	23
10	21	\N	t	\N	113	23
10	22	\N	t	\N	114	23
10	23	\N	t	\N	115	23
10	5	\N	t	\N	116	24
10	7	\N	t	\N	117	24
10	8	\N	t	\N	118	24
10	9	\N	t	\N	119	24
10	4	\N	t	\N	120	24
10	6	\N	t	\N	121	24
10	24	\N	t	\N	122	24
11	12	\N	t	\N	124	25
12	12	\N	t	\N	145	29
11	14	\N	t	\N	126	25
11	15	\N	t	\N	127	25
11	10	\N	t	\N	128	25
11	16	\N	t	\N	129	26
11	17	\N	t	\N	130	26
11	18	\N	t	\N	131	26
11	19	\N	t	\N	132	26
11	20	\N	t	\N	133	27
11	21	\N	t	\N	134	27
11	22	\N	t	\N	135	27
11	23	\N	t	\N	136	27
11	5	\N	t	\N	137	28
11	7	\N	t	\N	138	28
11	8	\N	t	\N	139	28
11	9	\N	t	\N	140	28
11	4	\N	t	\N	141	28
11	6	\N	t	\N	142	28
11	24	\N	t	\N	143	28
11	11	\N	f	\N	123	25
11	13	\N	f	\N	125	25
12	13	\N	t	\N	146	29
12	14	\N	t	\N	147	29
12	15	\N	t	\N	148	29
12	10	\N	t	\N	149	29
12	16	\N	t	\N	150	30
12	17	\N	t	\N	151	30
12	18	\N	t	\N	152	30
12	19	\N	t	\N	153	30
12	20	\N	t	\N	154	31
12	21	\N	t	\N	155	31
12	22	\N	t	\N	156	31
12	23	\N	t	\N	157	31
12	5	\N	t	\N	158	32
12	7	\N	t	\N	159	32
12	8	\N	t	\N	160	32
12	9	\N	t	\N	161	32
12	4	\N	t	\N	162	32
12	6	\N	t	\N	163	32
12	24	\N	t	\N	164	32
13	11	\N	t	\N	165	33
13	12	\N	t	\N	166	33
13	13	\N	t	\N	167	33
13	14	\N	t	\N	168	33
13	15	\N	t	\N	169	33
13	10	\N	t	\N	170	33
13	16	\N	t	\N	171	34
13	17	\N	t	\N	172	34
13	18	\N	t	\N	173	34
13	19	\N	t	\N	174	34
13	20	\N	t	\N	175	35
13	21	\N	t	\N	176	35
13	22	\N	t	\N	177	35
13	23	\N	t	\N	178	35
13	5	\N	t	\N	179	36
13	7	\N	t	\N	180	36
13	8	\N	t	\N	181	36
13	9	\N	t	\N	182	36
13	4	\N	t	\N	183	36
13	6	\N	t	\N	184	36
13	24	\N	t	\N	185	36
14	11	\N	t	\N	186	37
14	12	\N	t	\N	187	37
14	13	\N	t	\N	188	37
14	14	\N	t	\N	189	37
14	15	\N	t	\N	190	37
14	10	\N	t	\N	191	37
14	16	\N	t	\N	192	38
14	17	\N	t	\N	193	38
14	18	\N	t	\N	194	38
14	19	\N	t	\N	195	38
14	20	\N	t	\N	196	39
14	21	\N	t	\N	197	39
14	22	\N	t	\N	198	39
14	23	\N	t	\N	199	39
14	5	\N	t	\N	200	40
14	7	\N	t	\N	201	40
14	8	\N	t	\N	202	40
14	9	\N	t	\N	203	40
14	4	\N	t	\N	204	40
14	6	\N	t	\N	205	40
14	24	\N	t	\N	206	40
\.


--
-- Name: data_retention_guide_items_guide_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_retention_guide_items_guide_item_id_seq', 206, true);


--
-- Data for Name: data_retention_guides; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY data_retention_guides (guide_id, inclusion_status, complete_status, narrative, transparency_report_id) FROM stdin;
1	t	f	test test test	\N
2	t	f	This is a test. Yep.sd ""asda""	\N
4	t	f	test	\N
5	t	f	asfdasdf	\N
8	t	f	test tes test	\N
9	t	f	sadsd	\N
7	t	f	asdfasdf sdafasdf	\N
10	t	f	sdfgsdfgsdfg	\N
11	t	f	fghdfghdfgh	\N
13	\N	\N	\N	31
14	\N	\N	\N	32
12	\N	\N	fghfgh	\N
\.


--
-- Name: data_retention_guides_guide_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('data_retention_guides_guide_id_seq', 14, true);


--
-- Data for Name: government_request_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_categories (category_id, name, description) FROM stdin;
1	General Disclosures	asdfasdf!!
2	Court Ordered (Warranted) Disclosures	Court ordered disclosures refer to production orders, summons, subpoenas, and search warrants that are issued by a judge or judicial officer. They compel a company to collect and disclose information under the organization's control. In some cases an organization may challenge the disclosure of the information prior to disclosing it to the requesting government agency. Organizations should consult with counsel to determine their legal options in responding to court ordered disclosures of information to government agencies.\n\nThere are many different types of court ordered (warranted) disclosures. Some of the most common types of disclosures are included here by default.
3	Foreign Agency Requests (Court Ordered)	Canadian organizations may sometimes receive requests from non-Canadian agencies for access to information held by to Canadian organization. Such orders may be accompanied by a court order from the agency's jurisdiction. Alternately, the foreign order might be facilitated by Canadian agencies per the Mutual Legal Assistance in Criminal Matters Act.
4	Preservation Demands and Orders	Preservation demands and orders can be obtained under s.487.012 and 487.013 of the Criminal Code. Demands are made by peace or public officers whereas orders are made pursuant to judicial authority. These orders compel an organization to retain to identified information for 21 days (for domestic demands and orders) or 90 days (where the demand or order is made in order to assist an international investigation). Organizations are not required to disclose information prior to receiving a production order from the agency which served the demand or order. \n\nProduction orders are used to compel information from organizations, often after the organization has previously been compelled to preserve information after receiving a preservation demand or order. The preservation demands and orders category is used to identify the frequency at which preservation demands or orders are received, whereas the disclosure of actual data is reflected in one of the relevant court ordered disclosure category.
\.


--
-- Name: government_request_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_categories_category_id_seq', 4, true);


--
-- Data for Name: government_request_report_type_disclosures; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_report_type_disclosures (disclosure_id, request_report_id, request_type_id) FROM stdin;
4	\N	1
5	\N	3
6	\N	4
7	\N	5
8	\N	6
9	\N	7
10	\N	8
11	\N	9
12	\N	10
13	\N	11
14	5	1
15	5	3
16	5	4
17	5	5
18	5	6
19	5	7
20	5	8
21	5	9
22	5	10
23	5	11
24	6	1
25	6	3
26	6	4
27	6	5
28	6	6
29	6	7
30	6	8
31	6	9
32	6	10
33	6	11
34	7	1
35	7	3
36	7	4
37	7	5
38	7	6
39	7	7
40	7	8
41	7	9
42	7	10
43	7	11
\.


--
-- Name: government_request_report_type_disclosures_disclosure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_report_type_disclosures_disclosure_id_seq', 43, true);


--
-- Data for Name: government_request_responses; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_responses (response_id, name, description) FROM stdin;
2	Number of requests	Counting the number of requests entails adding the voluntary or court-mandated requests or orders received by an organization, as appropriate for each of the types of reporting categories.
4	Number of requests rejected	Organizations may sometimes reject requests for information that are made by government agencies. Rejections might be on the basis of improper request formats, on the basis of refusing to provide information absent a court order, or on the basis of other process or legal grounds. When preparing their reports, organizations should tabulate all of the legal or voluntary requests that they refuse, instead of tabulating the number of subscribers who would otherwise be affected by the request.
5	Number of requests contested	Organizations may sometimes dispute the requests that they receive from government agencies as a result of improperly scoped legal requests, on the basis of erroneous legal authorities being used to compel data from an organization, or on the basis of doubts concerning the legality or constitutionality of the request. Organizations should count each request they oppose, as opposed to tabulating the number of subscribers/accounts/customers who are affected by the initial request and subsequent contestation.
6	Number of requests for which the organization has no data	Government agencies may sometimes make requests or demands for information where the organization does not possess any relevant information. Organizations should count each request for which they lack data, as opposed to tabulating the number of subscribers, or accounts, or customers who would be affected by the request but for whom the organization possesses no relevant data.
7	Number of requests for which partial information disclosed	Government agencies may sometimes make requests or demands for information where the organization possesses only some relevant information. Organizations should count each request for which they partially possess data, as opposed to tabulating the number of subscribers/accounts/customers who would be affected by the request but for whom the organization only partially possesses data.
8	Number of requests for which information is fully disclosed	Government agencies may sometimes make requests or demands for information where the organization fully discloses the requested or demanded information. Organizations should count each request for which they fully disclose data, as opposed to tabulating the number of subscribers/accounts/customers who are affected by the disclosure.
9	Number of users notified	Government agencies' requests will often affect a series of an organization's subscribers, customers, or users. Sometimes, though not always, organizations may notify those affected of the request. Organizations should count each affected person that they notify of the request; where they a barred from informing all those affected an organization might denote that with a footnote associated with the reported number.
3	Number of subscribers / accounts / customers affected	It is possible that a single request might affect multiple subscribers, or accounts, or customers. A single order might name or otherwise identify each of the subscribers, or accounts, or customers or include an 'identifier' -- a piece of data that is then used by the organization to subsequently identify the subscribers, or accounts, or customers associated with the request. When preparing their reports, organizations should tabulate all of the subscribers, or accounts, or customers affected by each of the types of reporting category requests.
\.


--
-- Name: government_request_responses_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_responses_response_id_seq', 9, true);


--
-- Data for Name: government_request_types; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_request_types (type_id, category_id, name, description) FROM stdin;
1	1	Voluntary Disclosure Following Government Request	Government agencies will sometimes ask organizations to voluntarily provide certain information to the requesting authority. In some cases these requests may be made where the agency does not believe a warrant or court order is required to obtain the information, such as when conducting criminal investigations, to location or notify next-of-kin, return property, or help search for missing persons. Organizations are permitted to ask the requesting agency to return with a court order or explain what statute requires the disclosure before volunteering the requested information.
3	1	Voluntary Disclosure at Organization's Initiative	Organizations may voluntarily share information with government agencies, though organizations may prefer to consult with counsel before doing so in order to ensure they are properly respecting any terms of service, contracts, or other guarantees made between the organization and its customers/subscribers/users, as well as acting in compliance with Canadian law. When voluntarily disclosing information the organization provides information without the receiving government agency in question first requesting the relevant information.
4	1	Disclosure in Emergency or Exigent Circumstances	Government agencies may sometimes request rapid or immediate access to information retained by organizations due to exigent circumstances, where the agencies would normally require a court order to access the information in question. Such requests may be for: identifying information (e.g. customer name, telephone number, mailing address, email address, or other information needed by the organization to identify its subscribers or customers) as well as communications content or transmission data.
5	1	Disclosures to Comply with Federal Law	Federal government agencies may sometimes compel organizations to disclose information by exercising statutory authorities; this means that the agencies do not require a court order to compel the information from an organization. Some organizations refer to these as 'government requirement letters'.
6	1	Disclosures to Comply with Provincial Law	Provincial government agencies may sometimes compel organizations to disclose information by exercising statutory authorities; this means that the agencies do not require a court order to compel the information from an organization. Some organizations refer to these as 'government requirement letters'.
7	2	Basic identifying information (court ordered)	Such orders compel an organization to collect and disclose personal identifiers associated with a subscribers/customer/user. Identifiers may include customer name, telephone number, mailing address, email address, or other identifiers needed to identify a person where those identifiers enjoy a reasonable expectation of privacy and can only be disclosed pursuant to a court order.
8	2	Tracking data	Tracking data orders are obtained using tracking warrants, as denoted under s.492.1 of the Criminal Code. These orders are used to obtain data that relates to the location of a transaction, individual, or thing.
9	2	Transmission data	Transmission data orders are obtained using a transmission data recorder order, as denoted under s.492.2 of the Criminal Code. These orders are used to obtain data that is obtained by dialling, addressing, routing, or signalling, such as incoming and outgoing times of calls, non-content information associated with text messages or chat-based communications, or other data that does not reveal the content of the communication or message. Transmission data is more commonly known as 'metadata'.
10	2	Stored communications and other stored data	Stored communications and other stored data is often obtained using a warrant and production orders, as denoted under s.487, 487.01, and 487.014-487.018 of the Criminal Code. These orders may refer to historical data that includes the content of stored communications including email, chat messages, photos, documents, or any other kinds of stored data.
11	2	Real time interceptions	Real time interceptions are often obtained using a wiretap warrant, as denoted under Part VI of the Criminal Code. These orders may refer to private communications which are intercepted by means of electro-magnetic, acoustic, mechanical, or other means and involve the live capture of communications that are intermediated or accessible by the organization.
\.


--
-- Name: government_request_types_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_request_types_type_id_seq', 11, true);


--
-- Data for Name: government_requests_reports; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY government_requests_reports (report_id, transparency_report_id, inclusion_status, complete_status, narrative) FROM stdin;
6	31	\N	\N	\N
7	32	\N	\N	\N
5	\N	\N	\N	\N
\.


--
-- Name: government_requests_reports_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('government_requests_reports_report_id_seq', 7, true);


--
-- Name: law_enfocement_handbook_action_categor_handbook_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enfocement_handbook_action_categor_handbook_category_id_seq', 110, true);


--
-- Data for Name: law_enfocement_handbook_action_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enfocement_handbook_action_categories (handbook_id, action_category_id, inclusion_status, handbook_category_id) FROM stdin;
4	5	t	3
4	2	t	4
4	4	t	5
4	3	t	6
4	6	t	7
4	7	t	8
4	8	t	9
4	9	t	10
4	10	t	11
5	5	t	12
5	2	t	13
5	4	t	14
5	3	t	15
5	6	t	16
5	7	t	17
5	8	t	18
5	9	t	19
5	10	t	20
6	5	t	21
6	2	t	22
6	4	t	23
6	3	t	24
6	6	t	25
6	7	t	26
6	8	t	27
6	9	t	28
6	10	t	29
7	5	t	30
7	2	t	31
7	4	t	32
7	3	t	33
7	6	t	34
7	7	t	35
7	8	t	36
7	9	t	37
7	10	t	38
8	5	t	39
8	2	t	40
8	4	t	41
8	3	t	42
8	6	t	43
8	7	t	44
8	8	t	45
8	9	t	46
8	10	t	47
10	5	t	48
10	2	t	49
10	4	t	50
10	3	t	51
10	6	t	52
10	7	t	53
10	8	t	54
10	9	t	55
10	10	t	56
11	5	t	57
11	2	t	58
11	4	t	59
11	3	t	60
11	6	t	61
11	7	t	62
11	8	t	63
11	9	t	64
11	10	t	65
12	5	t	66
12	2	t	67
12	4	t	68
12	3	t	69
12	6	t	70
12	7	t	71
12	8	t	72
12	9	t	73
12	10	t	74
13	5	t	75
13	2	t	76
13	4	t	77
13	3	t	78
13	6	t	79
13	7	t	80
13	8	t	81
13	9	t	82
13	10	t	83
14	5	t	84
14	2	t	85
14	4	t	86
14	3	t	87
14	6	t	88
14	7	t	89
14	8	t	90
14	9	t	91
14	10	t	92
15	5	t	93
15	2	t	94
15	4	t	95
15	3	t	96
15	6	t	97
15	7	t	98
15	8	t	99
15	9	t	100
15	10	t	101
16	5	t	102
16	2	t	103
16	4	t	104
16	3	t	105
16	6	t	106
16	7	t	107
16	8	t	108
16	9	t	109
16	10	t	110
\.


--
-- Data for Name: law_enfocement_handbook_actions; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enfocement_handbook_actions (handbook_id, action_id, narrative, inclusion_status, handbook_category_id, handbook_action_id) FROM stdin;
4	1	\N	t	4	1
4	2	\N	t	4	2
4	3	\N	t	4	3
4	4	\N	t	4	4
4	5	\N	t	4	5
4	10	\N	t	5	6
4	11	\N	t	5	7
4	12	\N	t	5	8
4	13	\N	t	5	9
4	14	\N	t	5	10
4	15	\N	t	5	11
4	6	\N	t	6	12
4	7	\N	t	6	13
4	8	\N	t	6	14
4	9	\N	t	6	15
4	16	\N	t	7	16
4	17	\N	t	7	17
4	18	\N	t	7	18
4	19	\N	t	8	19
4	20	\N	t	8	20
4	21	\N	t	8	21
4	22	\N	t	8	22
4	23	\N	t	9	23
4	24	\N	t	10	24
4	25	\N	t	11	25
4	26	\N	t	11	26
4	27	\N	t	11	27
5	1	\N	t	13	28
5	2	\N	t	13	29
5	3	\N	t	13	30
5	4	\N	t	13	31
5	5	\N	t	13	32
5	10	\N	t	14	33
5	11	\N	t	14	34
5	12	\N	t	14	35
5	13	\N	t	14	36
5	14	\N	t	14	37
5	15	\N	t	14	38
5	6	\N	t	15	39
5	7	\N	t	15	40
5	8	\N	t	15	41
5	9	\N	t	15	42
5	16	\N	t	16	43
5	17	\N	t	16	44
5	18	\N	t	16	45
5	19	\N	t	17	46
5	20	\N	t	17	47
5	21	\N	t	17	48
5	22	\N	t	17	49
5	23	\N	t	18	50
5	24	\N	t	19	51
5	25	\N	t	20	52
5	26	\N	t	20	53
5	27	\N	t	20	54
6	1	\N	t	22	55
6	2	\N	t	22	56
6	3	\N	t	22	57
6	4	\N	t	22	58
6	5	\N	t	22	59
6	10	\N	t	23	60
6	11	\N	t	23	61
6	12	\N	t	23	62
6	13	\N	t	23	63
6	14	\N	t	23	64
6	15	\N	t	23	65
6	6	\N	t	24	66
6	7	\N	t	24	67
6	8	\N	t	24	68
6	9	\N	t	24	69
6	16	\N	t	25	70
6	17	\N	t	25	71
6	18	\N	t	25	72
6	19	\N	t	26	73
6	20	\N	t	26	74
6	21	\N	t	26	75
6	22	\N	t	26	76
6	23	\N	t	27	77
6	24	\N	t	28	78
6	25	\N	t	29	79
6	26	\N	t	29	80
6	27	\N	t	29	81
7	1	\N	t	31	82
7	2	\N	t	31	83
7	3	\N	t	31	84
7	4	\N	t	31	85
7	5	\N	t	31	86
7	10	\N	t	32	87
7	11	\N	t	32	88
7	12	\N	t	32	89
7	13	\N	t	32	90
7	14	\N	t	32	91
7	15	\N	t	32	92
7	6	\N	t	33	93
7	7	\N	t	33	94
7	8	\N	t	33	95
7	9	\N	t	33	96
7	16	\N	t	34	97
7	17	\N	t	34	98
7	18	\N	t	34	99
7	19	\N	t	35	100
7	20	\N	t	35	101
7	21	\N	t	35	102
7	22	\N	t	35	103
7	23	\N	t	36	104
7	24	\N	t	37	105
7	25	\N	t	38	106
7	26	\N	t	38	107
7	27	\N	t	38	108
8	28	\N	t	39	109
8	29	\N	t	39	110
8	30	\N	t	39	111
8	1	\N	t	40	112
8	2	\N	t	40	113
8	3	\N	t	40	114
8	4	\N	t	40	115
8	5	\N	t	40	116
8	10	\N	t	41	117
8	11	\N	t	41	118
8	12	\N	t	41	119
8	13	\N	t	41	120
8	14	\N	t	41	121
8	15	\N	t	41	122
8	6	\N	t	42	123
8	7	\N	t	42	124
8	8	\N	t	42	125
8	9	\N	t	42	126
8	16	\N	t	43	127
8	17	\N	t	43	128
8	18	\N	t	43	129
8	19	\N	t	44	130
8	20	\N	t	44	131
8	21	\N	t	44	132
8	22	\N	t	44	133
8	23	\N	t	45	134
8	24	\N	t	46	135
8	25	\N	t	47	136
8	26	\N	t	47	137
8	27	\N	t	47	138
10	28	\N	t	48	139
10	29	\N	t	48	140
10	30	\N	t	48	141
10	1	\N	t	49	142
10	2	\N	t	49	143
10	3	\N	t	49	144
10	4	\N	t	49	145
10	5	\N	t	49	146
10	10	\N	t	50	147
10	11	\N	t	50	148
10	12	\N	t	50	149
10	13	\N	t	50	150
10	14	\N	t	50	151
10	15	\N	t	50	152
10	6	\N	t	51	153
10	7	\N	t	51	154
10	8	\N	t	51	155
10	9	\N	t	51	156
10	16	\N	t	52	157
10	17	\N	t	52	158
10	18	\N	t	52	159
10	19	\N	t	53	160
10	20	\N	t	53	161
10	21	\N	t	53	162
10	22	\N	t	53	163
10	23	\N	f	54	164
10	24	\N	f	55	165
10	25	\N	t	56	166
10	26	\N	t	56	167
10	27	\N	t	56	168
11	28	\N	t	57	169
11	29	\N	t	57	170
11	30	\N	t	57	171
11	1	\N	f	58	172
11	2	\N	f	58	173
11	3	\N	f	58	174
11	4	\N	f	58	175
11	5	\N	f	58	176
11	10	\N	f	59	177
11	11	\N	f	59	178
11	12	\N	f	59	179
11	13	\N	f	59	180
11	14	\N	f	59	181
11	15	\N	f	59	182
11	6	\N	f	60	183
11	7	\N	f	60	184
11	8	\N	f	60	185
11	9	\N	f	60	186
11	16	\N	t	61	187
11	17	\N	t	61	188
11	18	\N	t	61	189
11	19	\N	f	62	190
11	20	\N	f	62	191
11	21	\N	f	62	192
11	22	\N	f	62	193
11	23	\N	t	63	194
11	24	\N	t	64	195
11	25	\N	t	65	196
11	26	\N	t	65	197
11	27	\N	t	65	198
15	28	\N	t	93	289
12	29	\N	f	66	200
12	30	\N	f	66	201
12	1	\N	t	67	202
12	2	\N	t	67	203
12	3	\N	t	67	204
12	4	\N	t	67	205
12	5	\N	t	67	206
12	10	\N	t	68	207
12	11	\N	t	68	208
12	12	\N	t	68	209
12	13	\N	t	68	210
12	14	\N	t	68	211
12	15	\N	t	68	212
12	6	\N	t	69	213
12	7	\N	t	69	214
12	8	\N	t	69	215
12	9	\N	t	69	216
12	16	\N	f	70	217
12	18	\N	f	70	219
12	19	\N	t	71	220
12	20	\N	t	71	221
12	21	\N	t	71	222
12	22	\N	t	71	223
12	23	\N	t	72	224
12	24	\N	t	73	225
12	25	\N	f	74	226
12	26	\N	f	74	227
12	27	\N	f	74	228
14	28	\N	t	84	259
12	28	\N	t	66	199
12	17	\N	t	70	218
13	29	\N	f	75	230
13	30	\N	f	75	231
13	1	\N	t	76	232
13	2	\N	t	76	233
13	3	\N	t	76	234
13	4	\N	t	76	235
13	5	\N	t	76	236
13	10	\N	t	77	237
13	11	\N	t	77	238
13	12	\N	t	77	239
13	13	\N	t	77	240
13	14	\N	t	77	241
13	15	\N	t	77	242
13	6	\N	t	78	243
13	7	\N	t	78	244
13	8	\N	t	78	245
13	9	\N	t	78	246
13	16	\N	f	79	247
13	18	\N	f	79	249
13	19	\N	t	80	250
13	20	\N	t	80	251
13	21	\N	t	80	252
13	22	\N	t	80	253
13	23	\N	t	81	254
13	24	\N	t	82	255
13	25	\N	f	83	256
13	26	\N	f	83	257
13	27	\N	f	83	258
13	28	\N	t	75	229
13	17	\N	t	79	248
14	29	\N	f	84	260
14	30	\N	f	84	261
14	1	\N	t	85	262
14	2	\N	t	85	263
14	3	\N	t	85	264
14	4	\N	t	85	265
14	5	\N	t	85	266
14	10	\N	t	86	267
14	11	\N	t	86	268
14	12	\N	t	86	269
14	13	\N	t	86	270
14	14	\N	t	86	271
14	15	\N	t	86	272
14	6	\N	t	87	273
14	7	\N	t	87	274
14	8	\N	t	87	275
14	9	\N	t	87	276
14	16	\N	f	88	277
14	17	\N	f	88	278
14	18	\N	f	88	279
14	19	\N	t	89	280
14	20	\N	t	89	281
14	21	\N	t	89	282
14	22	\N	t	89	283
14	23	\N	t	90	284
14	24	\N	t	91	285
14	25	\N	f	92	286
14	26	\N	f	92	287
14	27	\N	f	92	288
15	29	\N	f	93	290
15	30	\N	f	93	291
15	1	\N	t	94	292
15	2	\N	t	94	293
15	3	\N	t	94	294
15	4	\N	t	94	295
15	5	\N	t	94	296
15	10	\N	t	95	297
15	11	\N	t	95	298
15	12	\N	t	95	299
15	13	\N	t	95	300
15	14	\N	t	95	301
15	15	\N	t	95	302
15	6	\N	t	96	303
15	7	\N	t	96	304
15	8	\N	t	96	305
15	9	\N	t	96	306
15	16	\N	f	97	307
15	17	\N	f	97	308
15	18	\N	f	97	309
15	19	\N	t	98	310
15	20	\N	t	98	311
15	21	\N	t	98	312
15	22	\N	t	98	313
15	26	\N	f	101	317
15	27	\N	f	101	318
15	23	sdfsdf	t	99	314
15	24	sdfsdfsdf	t	100	315
15	25	\N	t	101	316
16	28	\N	f	102	319
16	29	\N	f	102	320
16	30	\N	f	102	321
16	1	\N	t	103	322
16	2	\N	t	103	323
16	3	\N	t	103	324
16	4	\N	t	103	325
16	5	\N	t	103	326
16	10	\N	t	104	327
16	11	\N	t	104	328
16	12	\N	t	104	329
16	13	\N	t	104	330
16	14	\N	t	104	331
16	15	\N	t	104	332
16	6	\N	t	105	333
16	7	\N	t	105	334
16	8	\N	t	105	335
16	9	\N	t	105	336
16	16	\N	f	106	337
16	17	\N	f	106	338
16	18	\N	f	106	339
16	19	\N	t	107	340
16	20	\N	t	107	341
16	21	\N	t	107	342
16	22	\N	t	107	343
16	23	\N	t	108	344
16	24	\N	t	109	345
16	25	\N	f	110	346
16	26	\N	f	110	347
16	27	\N	f	110	348
\.


--
-- Name: law_enfocement_handbook_actions_handbook_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enfocement_handbook_actions_handbook_action_id_seq', 348, true);


--
-- Data for Name: law_enforcement_action_categories; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enforcement_action_categories (category_id, name, action_selection_type) FROM stdin;
5	Are users notified?	1
2	How to serve request	2
4	What contact info should accompany request?	2
3	What types of requests can be made?	2
6	How we respond to international requests	1
7	Policy on emergency requests	2
8	What is service?	3
9	Requests for information	3
10	Cost reimbursement	1
\.


--
-- Name: law_enforcement_action_categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enforcement_action_categories_category_id_seq', 10, true);


--
-- Data for Name: law_enforcement_actions; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enforcement_actions (action_id, category_id, name, narrative, narrative_label) FROM stdin;
1	2	Fee	Blah	\N
2	2	Phone	asdf	\N
3	2	Email	test	\N
4	2	Certified Mail	test	\N
5	2	Courier	asdf	asdf
6	3	Voluntary disclosure	test	\N
7	3	Government statutory / requirement letters	test	\N
8	3	Court orders	test	\N
9	3	Emergency requests	test	\N
11	4	Requesting Agency Officer Name / badge ID	asdfasd	\N
12	4	Requesting Agent's email address	asdfasdf	\N
13	4	Requesting Agent's Phone Contact	asdfasdf	\N
14	4	Requesting Agency's Mailing Address	asdfasd	\N
15	4	Requested Response Date	asdfasd	\N
10	4	Requesting Agency Name	test	\N
16	6	Accept	asdf	\N
17	6	Reject	asdf	\N
18	6	Require MLAT	asdf	\N
19	7	Require Emergency Contact Letter	asdfasdf	\N
20	7	Phone	asdf	\N
21	7	Fax	adfgadfg	\N
22	7	Email	asdf	\N
23	8	Service provided	asdf	\N
24	9	Requests for information	adsf	\N
25	10	Will seek	asdf	\N
26	10	Will sometimes seek	asdf	\N
27	10	Will not seek	asdfasdf	\N
28	5	Yes	asdf	\N
29	5	No	asdf	\N
30	5	Sometimes	asdf	\N
\.


--
-- Name: law_enforcement_actions_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enforcement_actions_action_id_seq', 30, true);


--
-- Data for Name: law_enforcement_handbooks; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY law_enforcement_handbooks (handbook_id, inclusion_status, complete_status, narrative, date_updated, date_updated_inclusion_status, transparency_report_id) FROM stdin;
4	t	f	dfgdsgsdfg	\N	\N	\N
5	t	f	dfgdsgsdfg	\N	\N	\N
6	t	f	dfgdsgsdfg	\N	\N	\N
8	t	f	asdfasdf	\N	\N	\N
10	t	f	asDasd	\N	\N	\N
7	t	f	dfgdsgsdfg	\N	\N	\N
11	t	f	asdfasdf	\N	\N	\N
12	t	f	asdfasdf	\N	\N	\N
13	t	f	dsrsfgh	\N	\N	\N
15	\N	\N	\N	\N	\N	31
16	\N	\N	\N	\N	\N	32
14	\N	\N	\N	\N	\N	\N
\.


--
-- Name: law_enforcement_handbooks_handbook_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('law_enforcement_handbooks_handbook_id_seq', 16, true);


--
-- Data for Name: transparency_reports; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY transparency_reports (report_id, publication_status, complete_status, publication_date, update_date, report_period_start, report_period_end, author_name) FROM stdin;
31	\N	\N	2016-06-30	\N	2016-06-08	2016-06-29	dfsgsdfgfsd
32	\N	\N	2016-06-30	\N	2016-06-09	2016-06-29	sdfg sdf gsd f
\.


--
-- Name: transparency_reports_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('transparency_reports_report_id_seq', 32, true);


--
-- Data for Name: type_disclosure_responses; Type: TABLE DATA; Schema: public; Owner: transdb
--

COPY type_disclosure_responses (response_id, disclosure_id, count, type_disclosure_id) FROM stdin;
4	4	0	11
5	4	0	12
6	4	0	13
7	4	0	14
8	4	0	15
9	4	0	16
2	5	0	17
3	5	0	18
4	5	0	19
5	5	0	20
6	5	0	21
7	5	0	22
8	5	0	23
9	5	0	24
2	6	0	25
3	6	0	26
4	6	0	27
5	6	0	28
6	6	0	29
7	6	0	30
8	6	0	31
9	6	0	32
2	7	0	33
3	7	0	34
4	7	0	35
5	7	0	36
6	7	0	37
7	7	0	38
8	7	0	39
9	7	0	40
2	8	0	41
3	8	0	42
4	8	0	43
5	8	0	44
6	8	0	45
7	8	0	46
8	8	0	47
9	8	0	48
2	9	0	49
3	9	0	50
4	9	0	51
5	9	0	52
6	9	0	53
7	9	0	54
8	9	0	55
9	9	0	56
2	10	0	57
3	10	0	58
4	10	0	59
5	10	0	60
6	10	0	61
7	10	0	62
8	10	0	63
9	10	0	64
2	11	0	65
3	11	0	66
4	11	0	67
5	11	0	68
6	11	0	69
7	11	0	70
8	11	0	71
9	11	0	72
2	12	0	73
3	12	0	74
4	12	0	75
5	12	0	76
6	12	0	77
7	12	0	78
8	12	0	79
9	12	0	80
2	13	0	81
3	13	0	82
4	13	0	83
5	13	0	84
6	13	0	85
7	13	0	86
8	13	0	87
9	13	0	88
2	24	0	169
4	24	0	170
3	4	123324	10
2	14	4540	89
4	14	23423	90
5	14	123	91
7	14	234	93
2	4	122	9
6	14	0	92
8	14	0	94
9	14	0	95
3	14	0	96
2	15	0	97
4	15	0	98
5	15	0	99
7	15	0	101
8	15	0	102
9	15	0	103
3	15	0	104
2	16	0	105
4	16	0	106
5	16	0	107
6	16	0	108
7	16	0	109
8	16	0	110
9	16	0	111
3	16	0	112
2	17	0	113
4	17	0	114
5	17	0	115
6	17	0	116
7	17	0	117
8	17	0	118
9	17	0	119
3	17	0	120
2	18	0	121
4	18	0	122
5	18	0	123
6	18	0	124
7	18	0	125
8	18	0	126
9	18	0	127
3	18	0	128
2	19	0	129
4	19	0	130
5	19	0	131
6	19	0	132
7	19	0	133
8	19	0	134
9	19	0	135
3	19	0	136
2	20	0	137
4	20	0	138
5	20	0	139
6	20	0	140
7	20	0	141
8	20	0	142
9	20	0	143
3	20	0	144
2	21	0	145
4	21	0	146
5	21	0	147
6	21	0	148
7	21	0	149
8	21	0	150
9	21	0	151
3	21	0	152
2	22	0	153
4	22	0	154
5	22	0	155
6	22	0	156
7	22	0	157
8	22	0	158
9	22	0	159
3	22	0	160
2	23	0	161
4	23	0	162
5	23	0	163
6	23	0	164
7	23	0	165
8	23	0	166
9	23	0	167
3	23	0	168
6	15	0	100
5	24	0	171
6	24	0	172
7	24	0	173
8	24	0	174
9	24	0	175
3	24	0	176
2	25	0	177
4	25	0	178
5	25	0	179
6	25	0	180
7	25	0	181
8	25	0	182
9	25	0	183
3	25	0	184
2	26	0	185
4	26	0	186
5	26	0	187
6	26	0	188
7	26	0	189
8	26	0	190
9	26	0	191
3	26	0	192
2	27	0	193
4	27	0	194
5	27	0	195
6	27	0	196
7	27	0	197
8	27	0	198
9	27	0	199
3	27	0	200
2	28	0	201
4	28	0	202
5	28	0	203
6	28	0	204
7	28	0	205
8	28	0	206
9	28	0	207
3	28	0	208
2	29	0	209
4	29	0	210
5	29	0	211
6	29	0	212
7	29	0	213
8	29	0	214
9	29	0	215
3	29	0	216
2	30	0	217
4	30	0	218
5	30	0	219
6	30	0	220
7	30	0	221
8	30	0	222
9	30	0	223
3	30	0	224
2	31	0	225
4	31	0	226
5	31	0	227
6	31	0	228
7	31	0	229
8	31	0	230
9	31	0	231
3	31	0	232
2	32	0	233
4	32	0	234
5	32	0	235
6	32	0	236
7	32	0	237
8	32	0	238
9	32	0	239
3	32	0	240
2	33	0	241
4	33	0	242
5	33	0	243
6	33	0	244
7	33	0	245
8	33	0	246
9	33	0	247
3	33	0	248
2	34	0	249
4	34	0	250
5	34	0	251
6	34	0	252
7	34	0	253
8	34	0	254
9	34	0	255
3	34	0	256
2	35	0	257
4	35	0	258
5	35	0	259
6	35	0	260
7	35	0	261
8	35	0	262
9	35	0	263
3	35	0	264
2	36	0	265
4	36	0	266
5	36	0	267
6	36	0	268
7	36	0	269
8	36	0	270
9	36	0	271
3	36	0	272
2	37	0	273
4	37	0	274
5	37	0	275
6	37	0	276
7	37	0	277
8	37	0	278
9	37	0	279
3	37	0	280
2	38	0	281
4	38	0	282
5	38	0	283
6	38	0	284
7	38	0	285
8	38	0	286
9	38	0	287
3	38	0	288
2	39	0	289
4	39	0	290
5	39	0	291
6	39	0	292
7	39	0	293
8	39	0	294
9	39	0	295
3	39	0	296
2	40	0	297
4	40	0	298
5	40	0	299
6	40	0	300
7	40	0	301
8	40	0	302
9	40	0	303
3	40	0	304
2	41	0	305
4	41	0	306
5	41	0	307
6	41	0	308
7	41	0	309
8	41	0	310
9	41	0	311
3	41	0	312
2	42	0	313
4	42	0	314
5	42	0	315
6	42	0	316
7	42	0	317
8	42	0	318
9	42	0	319
3	42	0	320
2	43	0	321
4	43	0	322
5	43	0	323
6	43	0	324
7	43	0	325
8	43	0	326
9	43	0	327
3	43	0	328
\.


--
-- Name: type_disclosure_responses_type_disclosure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: transdb
--

SELECT pg_catalog.setval('type_disclosure_responses_type_disclosure_id_seq', 328, true);


--
-- Name: data_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_categories
    ADD CONSTRAINT data_categories_pkey PRIMARY KEY (category_id);


--
-- Name: data_items_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_items
    ADD CONSTRAINT data_items_pkey PRIMARY KEY (item_id);


--
-- Name: data_retention_guide_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_retention_guide_categories
    ADD CONSTRAINT data_retention_guide_categories_pkey PRIMARY KEY (guide_category_id);


--
-- Name: data_retention_guide_items_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_pkey PRIMARY KEY (guide_item_id);


--
-- Name: data_retention_guides_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY data_retention_guides
    ADD CONSTRAINT data_retention_guides_pkey PRIMARY KEY (guide_id);


--
-- Name: government_request_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_categories
    ADD CONSTRAINT government_request_categories_pkey PRIMARY KEY (category_id);


--
-- Name: government_request_report_type_disclosures_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_report_type_disclosures
    ADD CONSTRAINT government_request_report_type_disclosures_pkey PRIMARY KEY (disclosure_id);


--
-- Name: government_request_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_responses
    ADD CONSTRAINT government_request_responses_pkey PRIMARY KEY (response_id);


--
-- Name: government_request_types_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_request_types
    ADD CONSTRAINT government_request_types_pkey PRIMARY KEY (type_id);


--
-- Name: government_requests_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY government_requests_reports
    ADD CONSTRAINT government_requests_reports_pkey PRIMARY KEY (report_id);


--
-- Name: law_enfocement_handbook_action_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories
    ADD CONSTRAINT law_enfocement_handbook_action_categories_pkey PRIMARY KEY (handbook_category_id);


--
-- Name: law_enfocement_handbook_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_pkey PRIMARY KEY (handbook_action_id);


--
-- Name: law_enforcement_action_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enforcement_action_categories
    ADD CONSTRAINT law_enforcement_action_categories_pkey PRIMARY KEY (category_id);


--
-- Name: law_enforcement_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enforcement_actions
    ADD CONSTRAINT law_enforcement_actions_pkey PRIMARY KEY (action_id);


--
-- Name: law_enforcement_handbooks_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY law_enforcement_handbooks
    ADD CONSTRAINT law_enforcement_handbooks_pkey PRIMARY KEY (handbook_id);


--
-- Name: transparency_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY transparency_reports
    ADD CONSTRAINT transparency_reports_pkey PRIMARY KEY (report_id);


--
-- Name: type_disclosure_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: transdb; Tablespace: 
--

ALTER TABLE ONLY type_disclosure_responses
    ADD CONSTRAINT type_disclosure_responses_pkey PRIMARY KEY (type_disclosure_id);


--
-- Name: data_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_items
    ADD CONSTRAINT data_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES data_categories(category_id);


--
-- Name: data_retention_guide_categories_guide_data_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_categories
    ADD CONSTRAINT data_retention_guide_categories_guide_data_category_id_fkey FOREIGN KEY (guide_data_category_id) REFERENCES data_categories(category_id);


--
-- Name: data_retention_guide_categories_guide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_categories
    ADD CONSTRAINT data_retention_guide_categories_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES data_retention_guides(guide_id);


--
-- Name: data_retention_guide_items_guide_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_guide_category_id_fkey FOREIGN KEY (guide_category_id) REFERENCES data_retention_guide_categories(guide_category_id);


--
-- Name: data_retention_guide_items_guide_data_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_guide_data_item_id_fkey FOREIGN KEY (guide_data_item_id) REFERENCES data_items(item_id);


--
-- Name: data_retention_guide_items_guide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guide_items
    ADD CONSTRAINT data_retention_guide_items_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES data_retention_guides(guide_id);


--
-- Name: data_retention_guides_transparency_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY data_retention_guides
    ADD CONSTRAINT data_retention_guides_transparency_report_id_fkey FOREIGN KEY (transparency_report_id) REFERENCES transparency_reports(report_id);


--
-- Name: government_request_report_type_disclosur_request_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_report_type_disclosures
    ADD CONSTRAINT government_request_report_type_disclosur_request_report_id_fkey FOREIGN KEY (request_report_id) REFERENCES government_requests_reports(report_id);


--
-- Name: government_request_report_type_disclosures_request_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_report_type_disclosures
    ADD CONSTRAINT government_request_report_type_disclosures_request_type_id_fkey FOREIGN KEY (request_type_id) REFERENCES government_request_types(type_id);


--
-- Name: government_request_types_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_request_types
    ADD CONSTRAINT government_request_types_category_id_fkey FOREIGN KEY (category_id) REFERENCES government_request_categories(category_id);


--
-- Name: government_requests_reports_transparency_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY government_requests_reports
    ADD CONSTRAINT government_requests_reports_transparency_report_id_fkey FOREIGN KEY (transparency_report_id) REFERENCES transparency_reports(report_id);


--
-- Name: law_enfocement_handbook_action_categori_action_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories
    ADD CONSTRAINT law_enfocement_handbook_action_categori_action_category_id_fkey FOREIGN KEY (action_category_id) REFERENCES law_enforcement_action_categories(category_id);


--
-- Name: law_enfocement_handbook_action_categories_handbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_action_categories
    ADD CONSTRAINT law_enfocement_handbook_action_categories_handbook_id_fkey FOREIGN KEY (handbook_id) REFERENCES law_enforcement_handbooks(handbook_id);


--
-- Name: law_enfocement_handbook_actions_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_action_id_fkey FOREIGN KEY (action_id) REFERENCES law_enforcement_actions(action_id);


--
-- Name: law_enfocement_handbook_actions_handbook_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_handbook_category_id_fkey FOREIGN KEY (handbook_category_id) REFERENCES law_enfocement_handbook_action_categories(handbook_category_id);


--
-- Name: law_enfocement_handbook_actions_handbook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enfocement_handbook_actions
    ADD CONSTRAINT law_enfocement_handbook_actions_handbook_id_fkey FOREIGN KEY (handbook_id) REFERENCES law_enforcement_handbooks(handbook_id);


--
-- Name: law_enforcement_actions_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_actions
    ADD CONSTRAINT law_enforcement_actions_category_id_fkey FOREIGN KEY (category_id) REFERENCES law_enforcement_action_categories(category_id);


--
-- Name: law_enforcement_handbooks_transparency_report_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY law_enforcement_handbooks
    ADD CONSTRAINT law_enforcement_handbooks_transparency_report_id_fkey FOREIGN KEY (transparency_report_id) REFERENCES transparency_reports(report_id);


--
-- Name: type_disclosure_responses_disclosure_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY type_disclosure_responses
    ADD CONSTRAINT type_disclosure_responses_disclosure_id_fkey FOREIGN KEY (disclosure_id) REFERENCES government_request_report_type_disclosures(disclosure_id);


--
-- Name: type_disclosure_responses_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: transdb
--

ALTER TABLE ONLY type_disclosure_responses
    ADD CONSTRAINT type_disclosure_responses_response_id_fkey FOREIGN KEY (response_id) REFERENCES government_request_responses(response_id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

